# iPhone26 Launcher (starter)

Project Android Studio berbasis Kotlin + Jetpack Compose.

## Build
1. Buka folder ini melalui Android Studio.
2. Gunakan JDK 17 dan Android SDK 35.
3. Tunggu Gradle Sync.
4. Jalankan `:app:assembleDebug` atau tekan Run.

## Catatan fungsi
- Aplikasi mendaftarkan dirinya sebagai launcher HOME. Pilih "iPhone26 Launcher" sebagai aplikasi Home/default launcher ketika Android menawarkannya.
- Panel Control Center adalah panel di dalam aplikasi. Android tidak mengizinkan aplikasi biasa mengganti panel Quick Settings sistem secara penuh.
- Senter, brightness (setelah izin Modify system settings), dan volume menggunakan API Android.
- Tile Wi-Fi/Bluetooth saat ini hanya tampilan awal; tile tersebut belum mengubah status radio.
- Integrasi Shizuku saat ini mencakup pemeriksaan Binder dan permintaan izin dasar. Belum ada Shizuku UserService atau perintah privileged yang dijalankan.
- Untuk brightness, izinkan "Modify system settings" dari halaman yang dibuka aplikasi.
- Beberapa tindakan dibatasi versi Android, vendor, atau kebijakan keamanan perangkat.

Ini adalah starter project, bukan tiruan iOS resmi dan bukan pengganti system UI Android.
