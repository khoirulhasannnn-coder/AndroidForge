package com.iphone26.launcher

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.media.AudioManager
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private val shizukuRequestCode = 2201
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.BLACK
        setContent { LauncherScreen(onShizuku = { requestShizuku() }) }
    }
    private fun requestShizuku() {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) return
                Shizuku.requestPermission(shizukuRequestCode)
            }
        } catch (_: Exception) { }
    }
}

private data class AppTile(val name: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val color: Color)

@Composable
fun LauncherScreen(onShizuku: () -> Unit) {
    val context = LocalContext.current
    var controlOpen by remember { mutableStateOf(false) }
    var torchOn by remember { mutableStateOf(false) }
    var brightness by remember { mutableFloatStateOf(0.65f) }
    var volume by remember { mutableFloatStateOf(0.55f) }
    var shizukuStatus by remember { mutableStateOf("Periksa Shizuku") }

    val apps = listOf(
        AppTile("Telepon", Icons.Default.Call, Color(0xFF35C96B)),
        AppTile("Pesan", Icons.Default.Chat, Color(0xFF35C96B)),
        AppTile("Kamera", Icons.Default.CameraAlt, Color(0xFF777777)),
        AppTile("Foto", Icons.Default.Photo, Color(0xFFB77BE8)),
        AppTile("Pengaturan", Icons.Default.Settings, Color(0xFF858B95)),
        AppTile("Musik", Icons.Default.MusicNote, Color(0xFFE65B70)),
        AppTile("Jam", Icons.Default.AccessTime, Color(0xFF555B66)),
        AppTile("Play Store", Icons.Default.ShoppingBag, Color(0xFF4A91E8))
    )

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF152D55), Color(0xFF6B79A7), Color(0xFF171B2D))))
            .pointerInput(Unit) {
                var drag = 0f
                detectVerticalDragGestures(
                    onVerticalDrag = { _, amount -> drag += amount },
                    onDragEnd = { if (drag > 35) controlOpen = true; if (drag < -35) controlOpen = false; drag = 0f }
                )
            }
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 30.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("9:41", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("●  ▮▮▮  ▰", color = Color.White, fontSize = 14.sp)
            }
            Spacer(Modifier.height(55.dp))
            Text("Kamis, 19 November", color = Color.White.copy(.85f), fontSize = 17.sp)
            Text("9:41", color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light)
            Spacer(Modifier.weight(1f))
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.height(235.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                items(apps) { app ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { openAppOrSettings(context, app.name) }) {
                        Box(Modifier.size(58.dp).background(app.color, RoundedCornerShape(17.dp)),
                            contentAlignment = Alignment.Center) {
                            Icon(app.icon, contentDescription = app.name, tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                        Spacer(Modifier.height(5.dp))
                        Text(app.name, color = Color.White, fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(
                Modifier.fillMaxWidth().background(Color.White.copy(.18f), RoundedCornerShape(28.dp)).padding(12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf(Icons.Default.Call, Icons.Default.Language, Icons.Default.Message, Icons.Default.MusicNote).forEach {
                    Icon(it, null, tint = Color.White, modifier = Modifier.size(30.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Geser ke bawah untuk Control Center", color = Color.White.copy(.8f), fontSize = 11.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally))
        }

        if (controlOpen) {
            ControlCenter(
                torchOn = torchOn,
                onTorch = {
                    torchOn = !torchOn
                    setTorch(context, torchOn)
                },
                brightness = brightness,
                onBrightness = { brightness = it; setBrightness(context, it) },
                volume = volume,
                onVolume = { volume = it; setVolume(context, it) },
                shizukuStatus = shizukuStatus,
                onShizuku = { onShizuku(); shizukuStatus = "Permintaan izin dikirim jika Shizuku aktif" },
                onClose = { controlOpen = false },
                onSettings = { context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            )
        }
    }
}

@Composable
private fun ControlCenter(
    torchOn: Boolean, onTorch: () -> Unit,
    brightness: Float, onBrightness: (Float) -> Unit,
    volume: Float, onVolume: (Float) -> Unit,
    shizukuStatus: String, onShizuku: () -> Unit,
    onClose: () -> Unit, onSettings: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().background(Color(0xE91A1D27)).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Control Center", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Tutup ✕", color = Color.White, modifier = Modifier.clickable { onClose() })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ControlTile("Wi-Fi", Icons.Default.Wifi, "Buka pengaturan", Modifier.weight(1f)) { }
            ControlTile("Bluetooth", Icons.Default.Bluetooth, "Buka pengaturan", Modifier.weight(1f)) { }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ControlTile("Senter", Icons.Default.FlashlightOn, if (torchOn) "Aktif" else "Mati", Modifier.weight(1f), onTorch)
            ControlTile("Pengaturan", Icons.Default.Settings, "Sistem", Modifier.weight(1f), onSettings)
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(.13f)), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Brightness6, null, tint = Color.White)
                    Text("  Kecerahan", color = Color.White)
                }
                Slider(value = brightness, onValueChange = onBrightness)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(.13f)), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VolumeUp, null, tint = Color.White)
                    Text("  Volume media", color = Color.White)
                }
                Slider(value = volume, onValueChange = onVolume)
            }
        }
        Button(onClick = onShizuku, modifier = Modifier.fillMaxWidth()) {
            Text("Hubungkan / minta izin Shizuku")
        }
        Text(shizukuStatus, color = Color.White.copy(.7f), fontSize = 12.sp)
        Text("Wi-Fi, Bluetooth, data seluler, dan mode pesawat dibatasi kebijakan Android. Tile jaringan di versi awal ini belum mengubah status langsung.",
            color = Color.White.copy(.65f), fontSize = 11.sp)
        Spacer(Modifier.weight(1f))
        Text("Geser ke atas atau tekan Tutup", color = Color.White.copy(.7f), modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun ControlTile(
    title: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
    subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit
) {
    Column(modifier.background(Color.White.copy(.14f), RoundedCornerShape(20.dp)).clickable { onClick() }.padding(16.dp)) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
        Text(subtitle, color = Color.White.copy(.65f), fontSize = 10.sp)
    }
}

private fun openAppOrSettings(context: Context, name: String) {
    val action = when (name) {
        "Pengaturan" -> Settings.ACTION_SETTINGS
        "Kamera" -> "android.media.action.IMAGE_CAPTURE"
        else -> null
    }
    if (action != null) try {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) { }
}

private fun setTorch(context: Context, enabled: Boolean) {
    try {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val camera = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        if (camera != null) manager.setTorchMode(camera, enabled)
    } catch (_: Exception) { }
}

private fun setBrightness(context: Context, value: Float) {
    try {
        if (Settings.System.canWrite(context)) {
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (value * 255).toInt())
        } else {
            context.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    } catch (_: Exception) { }
}

private fun setVolume(context: Context, value: Float) {
    try {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (max * value).toInt(), 0)
    } catch (_: Exception) { }
}
