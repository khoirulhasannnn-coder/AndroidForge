# iOS System UI — Shizuku Edition (starter project)

This ZIP contains an Android Studio project scaffold for a custom iOS-inspired Control Center.

## Included
- Kotlin + Jetpack Compose project structure
- Basic Control Center panel
- Volume slider
- Battery level/charging readout
- NotificationListenerService declaration and starter class
- Overlay permission entry point

## Important
This is a **starter scaffold**, not a completed or device-tested system replacement.
It has not been compiled or tested on Redmi Note 10S / MIUI.
The Wi-Fi, Bluetooth, mobile data, airplane mode toggles, Shizuku shell integration,
persistent overlay trigger, notification cards, music controls, and full iOS-style status bar
are not implemented in this ZIP.

Shizuku does not grant unrestricted access to Android system UI. Android/MIUI may block
specific system operations. Do not assume toggles will work until tested on-device.

## Build
Open the folder in Android Studio, allow Gradle sync, then use:
Build > Build Bundle(s) / APK(s) > Build APK(s)

Requires Android Studio with JDK 17 and internet access for Gradle dependencies.
