package com.example.iossystemui.ui

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.iossystemui.system.BatteryMonitor

class ControlCenterActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window.setDimAmount(0.35f)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                ControlCenterPanel(onDismiss = { finish() })
            }
        }
    }
}

@Composable
private fun ControlCenterPanel(onDismiss: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    var volume by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    val maxVolume = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat().coerceAtLeast(1f) }
    val battery = remember { BatteryMonitor(context).read() }

    Box(Modifier.fillMaxSize().background(Color(0x55000000)).clickable { onDismiss() }, contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier.padding(top = 48.dp, start = 12.dp, end = 12.dp)
                .fillMaxWidth().background(Color(0xE61C1C1E), RoundedCornerShape(30.dp))
                .clickable(enabled = false) {}.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Control Center", color = Color.White, fontSize = 22.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Tile("Wi-Fi", Modifier.weight(1f))
                Tile("Bluetooth", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Tile("Data seluler", Modifier.weight(1f))
                Tile("Mode pesawat", Modifier.weight(1f))
            }
            Surface(color = Color(0x33FFFFFF), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Volume media", color = Color.White)
                    Slider(value = volume, onValueChange = {
                        volume = it
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, it.toInt(), 0)
                    }, valueRange = 0f..maxVolume)
                }
            }
            Surface(color = Color(0x33FFFFFF), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Baterai ${battery.level}%", color = Color.White, fontSize = 18.sp)
                    Text(if (battery.charging) "Sedang mengisi daya" else "Tidak sedang mengisi daya", color = Color.LightGray)
                }
            }
        }
    }
}

@Composable
private fun Tile(label: String, modifier: Modifier = Modifier) {
    Surface(modifier.height(82.dp), color = Color(0xFF0A84FF), shape = RoundedCornerShape(22.dp)) {
        Box(Modifier.padding(14.dp), contentAlignment = Alignment.BottomStart) {
            Text(label, color = Color.White)
        }
    }
}
