package com.example.iossystemui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import com.example.iossystemui.ui.ControlCenterActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("iOS System UI — Shizuku Edition", style = MaterialTheme.typography.headlineSmall)
                    Button(onClick = { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }) {
                        Text("Izinkan tampil di atas aplikasi")
                    }
                    Button(onClick = { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) {
                        Text("Aktifkan akses notifikasi")
                    }
                    Button(onClick = { startActivity(Intent(this@MainActivity, ControlCenterActivity::class.java)) }) {
                        Text("Buka Control Center")
                    }
                    Text("Fondasi UI. Integrasi toggle Shizuku dan overlay trigger perlu dilengkapi serta diuji di MIUI.")
                }
            }
        }
    }
}
