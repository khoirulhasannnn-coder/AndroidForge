// File: app/build.gradle.kts (modul aplikasi)
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.iosstatusbar"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.iosstatusbar"
        minSdk = 26          // Android 8.0 ke atas (Redmi Note 10S = Android 13)
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
        aidl = true          // IUserService.aidl untuk Shizuku UserService
        buildConfig = true   // BuildConfig.VERSION_CODE dipakai saat bind UserService
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    // Shizuku API resmi (cek versi terbaru di https://central.sonatype.com/artifact/dev.rikka.shizuku/api)
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
