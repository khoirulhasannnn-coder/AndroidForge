# File: app/proguard-rules.pro
# Shizuku memanggil UserService lewat reflection, jadi jangan dihapus saat minify.
-keep class com.example.iosstatusbar.shizuku.ShellUserService { *; }
-keep class com.example.iosstatusbar.IUserService$Stub { *; }
