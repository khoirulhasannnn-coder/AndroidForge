// File: app/src/main/aidl/com/example/iosstatusbar/IUserService.aidl
package com.example.iosstatusbar;

// Antarmuka UserService. Dijalankan oleh Shizuku dengan uid shell (bukan root).
interface IUserService {
    // Wajib: kode 16777114 di AIDL setara 16777115 di sisi Shizuku (sesuai README Shizuku-API)
    void destroy() = 16777114;

    // Membaca setting global (hanya kunci dalam whitelist). Mengembalikan null jika tidak ada.
    String getGlobalSetting(String key) = 1;

    // Menulis setting global. value null/kosong berarti hapus setting. Mengembalikan true jika berhasil.
    boolean putGlobalSetting(String key, String value) = 2;
}
