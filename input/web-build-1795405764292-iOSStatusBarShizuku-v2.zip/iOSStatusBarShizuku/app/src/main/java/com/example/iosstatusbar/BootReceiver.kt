// File: app/src/main/java/com/example/iosstatusbar/BootReceiver.kt
package com.example.iosstatusbar

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.iosstatusbar.service.StatusBarOverlayService
import com.example.iosstatusbar.settings.AppSettings
import com.example.iosstatusbar.system.OverlayPermission

/** Menjalankan ulang overlay setelah reboot, hanya jika pengguna mengaktifkannya dan izin masih ada. */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!AppSettings(context).overlayEnabled) return
        if (!OverlayPermission.canDraw(context)) return
        val serviceIntent = Intent(context, StatusBarOverlayService::class.java)
            .setAction(StatusBarOverlayService.ACTION_START)
        runCatching { ContextCompat.startForegroundService(context, serviceIntent) }
    }
}
