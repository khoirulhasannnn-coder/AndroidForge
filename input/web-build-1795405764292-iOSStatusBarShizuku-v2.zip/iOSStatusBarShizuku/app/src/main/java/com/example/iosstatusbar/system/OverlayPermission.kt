// File: app/src/main/java/com/example/iosstatusbar/system/OverlayPermission.kt
package com.example.iosstatusbar.system

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/** Izin SYSTEM_ALERT_WINDOW ("Tampilkan di atas aplikasi lain"). Pengguna memberikannya secara manual. */
object OverlayPermission {

    fun canDraw(context: Context): Boolean = Settings.canDrawOverlays(context)

    /** Intent yang membuka layar izin overlay khusus untuk paket aplikasi ini. */
    fun settingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
}
