// File: app/src/main/java/com/example/iosstatusbar/shizuku/ShizukuManager.kt
package com.example.iosstatusbar.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.example.iosstatusbar.BuildConfig
import com.example.iosstatusbar.IUserService
import rikka.shizuku.Shizuku
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Pembungkus Shizuku API resmi: deteksi aplikasi & server, izin,
 * dan menjalankan operasi lewat UserService (proses shell Shizuku).
 */
object ShizukuManager {

    const val MANAGER_PACKAGE = "moe.shizuku.privileged.api"
    const val PERMISSION_REQUEST_CODE = 1001
    private const val SERVICE_TIMEOUT_MS = 8_000L

    private val mainHandler = Handler(Looper.getMainLooper())

    data class State(
        val managerInstalled: Boolean,
        val serverRunning: Boolean,
        val permissionGranted: Boolean,
    ) {
        /** Connected = server Shizuku hidup dan izin sudah diberikan ke aplikasi ini. */
        val connected: Boolean get() = serverRunning && permissionGranted
    }

    fun state(context: Context): State {
        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val granted = running && runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
        return State(isManagerInstalled(context), running, granted)
    }

    fun isManagerInstalled(context: Context): Boolean = try {
        context.packageManager.getPackageInfo(MANAGER_PACKAGE, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    /** Meminta izin Shizuku. Hasilnya diterima lewat OnRequestPermissionResultListener di MainActivity. */
    fun requestPermission() {
        runCatching { Shizuku.requestPermission(PERMISSION_REQUEST_CODE) }
    }

    /**
     * Menjalankan [block] di dalam UserService, lalu melepas service.
     * [block] mengembalikan true jika berhasil. [onDone] selalu dipanggil di main thread.
     */
    fun runInShell(context: Context, block: (IUserService) -> Boolean, onDone: (Boolean) -> Unit) {
        val finished = AtomicBoolean(false)
        fun finish(ok: Boolean) {
            if (finished.compareAndSet(false, true)) mainHandler.post { onDone(ok) }
        }

        val args = Shizuku.UserServiceArgs(
            ComponentName(context.packageName, ShellUserService::class.java.name)
        )
            .daemon(false)
            .tag("iosstatusbar-shell")
            .version(BuildConfig.VERSION_CODE)

        val connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                val self = this
                // Perintah shell butuh waktu, jadi dijalankan di background thread
                Thread {
                    val ok = runCatching {
                        block(IUserService.Stub.asInterface(binder))
                    }.getOrDefault(false)
                    runCatching { Shizuku.unbindUserService(args, self, true) }
                    finish(ok)
                }.start()
            }

            override fun onServiceDisconnected(name: ComponentName?) {}
        }

        mainHandler.postDelayed({ finish(false) }, SERVICE_TIMEOUT_MS)
        try {
            Shizuku.bindUserService(args, connection)
        } catch (e: Throwable) {
            finish(false)
        }
    }
}
