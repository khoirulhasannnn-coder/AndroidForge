// File: app/src/main/java/com/example/iosstatusbar/service/StatusBarOverlayService.kt
package com.example.iosstatusbar.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentCallbacks
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.example.iosstatusbar.MainActivity
import com.example.iosstatusbar.R
import com.example.iosstatusbar.settings.AppSettings
import com.example.iosstatusbar.status.DeviceStatusMonitor
import com.example.iosstatusbar.system.OverlayPermission
import com.example.iosstatusbar.ui.IosStatusBarView
import kotlin.math.roundToInt

/**
 * Overlay status bar: window TYPE_APPLICATION_OVERLAY di bagian atas layar.
 * Berjalan sebagai foreground service agar tidak dimatikan sistem.
 *
 * Overlay hanya MENIRU tampilan status bar, tidak mengubah System UI.
 * Window memakai FLAG_NOT_TOUCHABLE, jadi sentuhan tetap sampai ke status bar asli
 * dan aplikasi di bawahnya (tarik panel notifikasi tetap berfungsi).
 */
class StatusBarOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var settings: AppSettings
    private var overlayView: IosStatusBarView? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var monitor: DeviceStatusMonitor? = null

    // Dipanggil saat rotasi atau perubahan konfigurasi, supaya posisi cutout ikut berubah
    private val configCallbacks = object : ComponentCallbacks {
        override fun onConfigurationChanged(newConfig: Configuration) = applyLayout()
        override fun onLowMemory() {}
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        settings = AppSettings(this)
        registerComponentCallbacks(configCallbacks)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopOverlay()
            return START_NOT_STICKY
        }
        // Wajib dipanggil segera setelah startForegroundService
        startInForeground()
        if (!OverlayPermission.canDraw(this)) {
            stopOverlay()
            return START_NOT_STICKY
        }
        if (overlayView == null) showOverlay() else applySettings()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        removeOverlay()
        runCatching { unregisterComponentCallbacks(configCallbacks) }
        super.onDestroy()
    }

    private fun showOverlay() {
        val view = IosStatusBarView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            statusBarHeightPx(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            title = "iOSStatusBarOverlay"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // Overlay boleh menggambar di area cutout (kamera berlubang)
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
        }
        windowManager.addView(view, params)
        overlayView = view
        overlayParams = params
        isRunning = true
        applySettings()
        monitor = DeviceStatusMonitor(this) { status -> overlayView?.status = status }
            .also { it.start() }
    }

    /** Menerapkan tema, ukuran ikon, dan transparansi dari pengaturan yang tersimpan. */
    private fun applySettings() {
        val view = overlayView ?: return
        view.isDark = settings.darkTheme(this)
        view.iconScale = settings.iconScalePercent / 100f
        view.backgroundOpacity = 1f - settings.transparencyPercent / 100f
        view.showBatteryPercent = settings.showBatteryPercent
        applyLayout()
        monitor?.restart() // izin telepon mungkin baru saja diberikan
    }

    /** Menyesuaikan tinggi dengan status bar asli dan lebar aman dengan cutout. */
    private fun applyLayout() {
        val view = overlayView ?: return
        val params = overlayParams ?: return
        val (left, right) = cutoutInsets()
        view.leftInset = left
        view.rightInset = right
        val newHeight = statusBarHeightPx()
        if (params.height != newHeight) {
            params.height = newHeight
            runCatching { windowManager.updateViewLayout(view, params) }
        }
    }

    /** Lebar yang harus dihindari di kiri dan kanan. Cutout di tengah tidak perlu dihindari. */
    private fun cutoutInsets(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return 0 to 0
        val metrics = windowManager.currentWindowMetrics
        val screenWidth = metrics.bounds.width()
        val cutout = metrics.windowInsets.displayCutout ?: return 0 to 0
        val half = screenWidth / 2
        var left = 0
        var right = 0
        for (rect: Rect in cutout.boundingRects) {
            if (rect.right <= half) {
                left = maxOf(left, rect.right)
            } else if (rect.left >= half) {
                right = maxOf(right, screenWidth - rect.left)
            }
        }
        return left to right
    }

    private fun statusBarHeightPx(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) {
            resources.getDimensionPixelSize(id)
        } else {
            (24 * resources.displayMetrics.density).roundToInt()
        }
    }

    private fun startInForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this,
            1,
            Intent(this, StatusBarOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.overlay_running))
            .setContentIntent(openApp)
            .setOngoing(true)
            .setSilent(true)
            .addAction(0, getString(R.string.notif_stop), stop)
            .build()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notif_channel),
            NotificationManager.IMPORTANCE_LOW,
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun stopOverlay() {
        removeOverlay()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun removeOverlay() {
        monitor?.stop()
        monitor = null
        overlayView?.let { view ->
            runCatching { windowManager.removeViewImmediate(view) }
        }
        overlayView = null
        overlayParams = null
        isRunning = false
    }

    companion object {
        const val ACTION_START = "com.example.iosstatusbar.action.START"
        const val ACTION_STOP = "com.example.iosstatusbar.action.STOP"
        const val ACTION_REFRESH = "com.example.iosstatusbar.action.REFRESH"

        /** Dipakai UI untuk menampilkan status overlay yang sebenarnya. */
        @Volatile
        var isRunning: Boolean = false

        private const val CHANNEL_ID = "overlay_status"
        private const val NOTIFICATION_ID = 1001
    }
}
