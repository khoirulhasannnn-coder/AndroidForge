// File: app/src/main/java/com/example/iosstatusbar/status/DeviceStatusMonitor.kt
package com.example.iosstatusbar.status

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telephony.SignalStrength
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.text.format.DateFormat
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Membaca status perangkat dari API Android secara real-time:
 * - waktu sistem (diperbarui tiap 5 detik)
 * - baterai dan status charging (ACTION_BATTERY_CHANGED)
 * - Wi-Fi dan seluler (ConnectivityManager + TelephonyCallback)
 * Semua callback dikirim ke main thread lewat [onChange].
 */
class DeviceStatusMonitor(
    private val context: Context,
    private val onChange: (DeviceStatus) -> Unit,
) {
    private val main = Handler(Looper.getMainLooper())
    private val connectivity: ConnectivityManager =
        context.getSystemService(ConnectivityManager::class.java)
    private val wifiManager: WifiManager? =
        context.applicationContext.getSystemService(WifiManager::class.java)
    private val telephony: TelephonyManager? =
        context.getSystemService(TelephonyManager::class.java)

    private var running = false
    private var batteryPercent = -1
    private var charging = false
    private var wifiUp = false
    private var cellularUp = false
    private var cellularLevel: Int? = null
    private val networkCallbacks = mutableListOf<ConnectivityManager.NetworkCallback>()
    private var telephonyCallback: Any? = null // TelephonyCallback (API 31+), disimpan sebagai Any

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) = readBattery(intent)
    }

    private val ticker = object : Runnable {
        override fun run() {
            publish()
            main.postDelayed(this, TICK_MS)
        }
    }

    fun start() {
        if (running) return
        running = true

        // Nilai awal baterai langsung dari sticky broadcast
        ContextCompat.registerReceiver(
            context,
            batteryReceiver,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )?.let { readBattery(it) }

        watchTransport(NetworkCapabilities.TRANSPORT_WIFI) {
            wifiUp = it
            publish()
        }
        watchTransport(NetworkCapabilities.TRANSPORT_CELLULAR) {
            cellularUp = it
            publish()
        }
        startCellularSignal()
        main.post(ticker)
    }

    fun stop() {
        if (!running) return
        running = false
        main.removeCallbacks(ticker)
        runCatching { context.unregisterReceiver(batteryReceiver) }
        networkCallbacks.forEach { cb -> runCatching { connectivity.unregisterNetworkCallback(cb) } }
        networkCallbacks.clear()
        stopCellularSignal()
    }

    /** Mulai ulang, misalnya setelah izin READ_PHONE_STATE baru diberikan. */
    fun restart() {
        stop()
        start()
    }

    private fun readBattery(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        batteryPercent = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        publish()
    }

    /** Memantau satu jenis transport (Wi-Fi atau seluler) dan melaporkan apakah sedang aktif. */
    private fun watchTransport(transport: Int, onState: (Boolean) -> Unit) {
        val active = HashSet<Network>()
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                main.post {
                    active.add(network)
                    onState(active.isNotEmpty())
                }
            }

            override fun onLost(network: Network) {
                main.post {
                    active.remove(network)
                    onState(active.isNotEmpty())
                }
            }
        }
        val request = NetworkRequest.Builder().addTransportType(transport).build()
        runCatching { connectivity.registerNetworkCallback(request, callback) }
        networkCallbacks += callback
    }

    private fun startCellularSignal() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) registerTelephonyCallback()
    }

    @RequiresApi(Build.VERSION_CODES.S)
    @SuppressLint("MissingPermission")
    private fun registerTelephonyCallback() {
        val manager = telephony ?: return
        val callback = object : TelephonyCallback(), TelephonyCallback.SignalStrengthsListener {
            override fun onSignalStrengthsChanged(signalStrength: SignalStrength) {
                val level = signalStrength.level
                main.post {
                    cellularLevel = level
                    publish()
                }
            }
        }
        try {
            manager.registerTelephonyCallback(ContextCompat.getMainExecutor(context), callback)
            telephonyCallback = callback
        } catch (e: SecurityException) {
            telephonyCallback = null
        }
    }

    private fun stopCellularSignal() {
        val callback = telephonyCallback ?: return
        telephonyCallback = null
        cellularLevel = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) unregisterTelephony(callback)
    }

    @RequiresApi(Build.VERSION_CODES.S)
    private fun unregisterTelephony(callback: Any) {
        runCatching { telephony?.unregisterTelephonyCallback(callback as TelephonyCallback) }
    }

    /** Level Wi-Fi 0..3 dari RSSI. Jika RSSI tidak terbaca, ikon ditampilkan penuh sebagai "tersambung". */
    @Suppress("DEPRECATION")
    private fun wifiLevel(): Int {
        if (!wifiUp) return 0
        val rssi = runCatching { wifiManager?.connectionInfo?.rssi }.getOrNull()
        if (rssi == null || rssi <= -127) return 3
        return WifiManager.calculateSignalLevel(rssi, 4).coerceIn(0, 3)
    }

    private fun timeText(): String {
        val pattern = if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm"
        return SimpleDateFormat(pattern, Locale.getDefault()).format(Date())
    }

    private fun publish() {
        onChange(
            DeviceStatus(
                timeText = timeText(),
                batteryPercent = batteryPercent,
                isCharging = charging,
                wifiConnected = wifiUp,
                wifiLevel = wifiLevel(),
                cellularLevel = if (cellularUp) cellularLevel else null,
            )
        )
    }

    companion object {
        private const val TICK_MS = 5_000L
    }
}
