// File: app/src/main/java/com/example/iosstatusbar/status/DeviceStatus.kt
package com.example.iosstatusbar.status

/**
 * Snapshot status perangkat dari API Android.
 * Nilai yang tidak terbaca ditandai -1 atau null, tidak ditebak.
 */
data class DeviceStatus(
    val timeText: String = "",
    val batteryPercent: Int = -1,       // -1 = tidak diketahui
    val isCharging: Boolean = false,
    val wifiConnected: Boolean = false,
    val wifiLevel: Int = 0,             // 0..3, hanya dipakai jika wifiConnected
    val cellularLevel: Int? = null,     // 0..4; null = tidak tersedia atau izin belum diberikan
)
