// File: app/src/main/java/com/example/iosstatusbar/shizuku/ShellUserService.kt
package com.example.iosstatusbar.shizuku

import com.example.iosstatusbar.IUserService
import kotlin.system.exitProcess

/**
 * Berjalan di proses Shizuku (uid shell). Hanya melayani kunci setting yang
 * ada di [ALLOWED_KEYS], jadi bukan "shell bebas".
 * Argumen dikirim sebagai daftar terpisah (bukan lewat sh -c), sehingga tidak ada injeksi perintah.
 */
class ShellUserService : IUserService.Stub() {

    override fun destroy() {
        exitProcess(0)
    }

    override fun getGlobalSetting(key: String?): String? {
        val k = key?.takeIf { it in ALLOWED_KEYS } ?: return null
        val (output, _) = runCommand("settings", "get", "global", k)
        return output.takeIf { it.isNotEmpty() && it != "null" }
    }

    override fun putGlobalSetting(key: String?, value: String?): Boolean {
        val k = key?.takeIf { it in ALLOWED_KEYS } ?: return false
        return if (value.isNullOrEmpty()) {
            runCommand("settings", "delete", "global", k).second == 0
        } else {
            if (!VALUE_REGEX.matches(value)) return false
            runCommand("settings", "put", "global", k, value).second == 0
        }
    }

    /** Menjalankan perintah, lalu mengembalikan pasangan (output, exitCode). */
    private fun runCommand(vararg cmd: String): Pair<String, Int> {
        val process = ProcessBuilder(*cmd).redirectErrorStream(true).start()
        val output = process.inputStream.bufferedReader().use { it.readText() }.trim()
        val code = process.waitFor()
        return output to code
    }

    companion object {
        // Whitelist: hanya kunci yang dibutuhkan untuk menyembunyikan status bar asli
        private val ALLOWED_KEYS = setOf("policy_control")
        private val VALUE_REGEX = Regex("^[A-Za-z0-9._=*,\\-]{1,200}$")
    }
}
