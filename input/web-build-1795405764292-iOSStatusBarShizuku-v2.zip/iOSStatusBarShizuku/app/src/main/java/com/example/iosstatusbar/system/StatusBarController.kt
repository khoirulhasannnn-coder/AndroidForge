// File: app/src/main/java/com/example/iosstatusbar/system/StatusBarController.kt
package com.example.iosstatusbar.system

import android.content.Context
import com.example.iosstatusbar.settings.AppSettings
import com.example.iosstatusbar.shizuku.ShizukuManager

/**
 * Menyembunyikan status bar asli dan mengembalikannya.
 *
 * Caranya: setting global `policy_control` diberi nilai `immersive.status=*`
 * (mode immersive khusus status bar, sama seperti yang dipakai aplikasi immersive).
 *
 * CATATAN: `policy_control` bukan API publik yang didokumentasikan. Ini setting internal AOSP
 * dan perilakunya bisa berbeda di MIUI/HyperOS, jadi wajib diuji di perangkat.
 * Nilai asli selalu dicadangkan dulu, lalu dikembalikan saat Disable atau Restore.
 */
object StatusBarController {

    private const val POLICY_KEY = "policy_control"
    private const val HIDE_VALUE = "immersive.status=*"

    fun isOriginalHidden(context: Context): Boolean = AppSettings(context).hasPolicyBackup()

    /** Menyembunyikan status bar asli. [onResult] dipanggil di main thread. */
    fun hideOriginal(context: Context, onResult: (Boolean) -> Unit) {
        val settings = AppSettings(context)
        ShizukuManager.runInShell(context, { service ->
            if (!settings.hasPolicyBackup()) {
                val current = service.getGlobalSetting(POLICY_KEY)
                // Jika nilai saat ini sudah buatan kita (sisa crash), anggap nilai asli kosong
                settings.savePolicyBackup(if (current == HIDE_VALUE) null else current)
            }
            service.putGlobalSetting(POLICY_KEY, HIDE_VALUE)
        }, onResult)
    }

    /** Mengembalikan status bar asli seperti sebelum aplikasi mengubahnya. */
    fun restoreOriginal(context: Context, onResult: (Boolean) -> Unit) {
        val settings = AppSettings(context)
        if (!settings.hasPolicyBackup()) {
            onResult(true) // tidak ada yang perlu dikembalikan
            return
        }
        ShizukuManager.runInShell(context, { service ->
            val original = settings.loadPolicyBackup() // null berarti hapus setting
            val ok = service.putGlobalSetting(POLICY_KEY, original)
            if (ok) settings.clearPolicyBackup()
            ok
        }, onResult)
    }
}
