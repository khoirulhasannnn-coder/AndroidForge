// File: app/src/main/java/com/example/iosstatusbar/settings/AppSettings.kt
package com.example.iosstatusbar.settings

import android.content.Context
import android.content.res.Configuration

/** Konfigurasi aplikasi, disimpan lokal di SharedPreferences (tidak dikirim ke mana pun). */
class AppSettings(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("iosstatusbar_settings", Context.MODE_PRIVATE)

    enum class ThemeMode { SYSTEM, LIGHT, DARK }

    var themeMode: ThemeMode
        get() = ThemeMode.entries.getOrElse(prefs.getInt(KEY_THEME, 0)) { ThemeMode.SYSTEM }
        set(value) = prefs.edit().putInt(KEY_THEME, value.ordinal).apply()

    /** Skala ikon dalam persen: 80..140. */
    var iconScalePercent: Int
        get() = prefs.getInt(KEY_ICON_SCALE, 100)
        set(value) = prefs.edit().putInt(KEY_ICON_SCALE, value.coerceIn(80, 140)).apply()

    /** Transparansi latar overlay dalam persen: 0 = tidak transparan, 100 = transparan penuh. */
    var transparencyPercent: Int
        get() = prefs.getInt(KEY_TRANSPARENCY, 0)
        set(value) = prefs.edit().putInt(KEY_TRANSPARENCY, value.coerceIn(0, 100)).apply()

    /** Pilihan pengguna: sembunyikan status bar asli (membutuhkan Shizuku). */
    var hideOriginalStatusBar: Boolean
        get() = prefs.getBoolean(KEY_HIDE_ORIGINAL, false)
        set(value) = prefs.edit().putBoolean(KEY_HIDE_ORIGINAL, value).apply()

    /** Tampilkan angka persentase di dalam ikon baterai. */
    var showBatteryPercent: Boolean
        get() = prefs.getBoolean(KEY_BATTERY_PERCENT, false)
        set(value) = prefs.edit().putBoolean(KEY_BATTERY_PERCENT, value).apply()

    /** Keinginan pengguna agar overlay aktif (dipakai BootReceiver setelah reboot). */
    var overlayEnabled: Boolean
        get() = prefs.getBoolean(KEY_OVERLAY_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_OVERLAY_ENABLED, value).apply()

    /** Menentukan mode gelap berdasarkan pilihan tema (atau mengikuti sistem). */
    fun darkTheme(context: Context): Boolean = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM ->
            (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
    }

    // Cadangan nilai policy_control asli, sebelum aplikasi mengubahnya.
    fun hasPolicyBackup(): Boolean = prefs.contains(KEY_POLICY_BACKUP)

    fun savePolicyBackup(value: String?) {
        prefs.edit().putString(KEY_POLICY_BACKUP, value ?: NULL_MARKER).apply()
    }

    fun loadPolicyBackup(): String? =
        prefs.getString(KEY_POLICY_BACKUP, null)?.takeIf { it != NULL_MARKER }

    fun clearPolicyBackup() {
        prefs.edit().remove(KEY_POLICY_BACKUP).apply()
    }

    companion object {
        private const val KEY_THEME = "theme_mode"
        private const val KEY_ICON_SCALE = "icon_scale_percent"
        private const val KEY_TRANSPARENCY = "transparency_percent"
        private const val KEY_HIDE_ORIGINAL = "hide_original"
        private const val KEY_OVERLAY_ENABLED = "overlay_enabled"
        private const val KEY_BATTERY_PERCENT = "battery_percent"
        private const val KEY_POLICY_BACKUP = "policy_control_backup"
        private const val NULL_MARKER = "__null__"
    }
}
