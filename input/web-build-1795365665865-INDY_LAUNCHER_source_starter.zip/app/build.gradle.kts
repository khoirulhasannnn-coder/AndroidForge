plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.indy.launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.indy.launcher"
        minSdk = 26
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("dev.rikka.shizuku:api:13.1.5")
}
