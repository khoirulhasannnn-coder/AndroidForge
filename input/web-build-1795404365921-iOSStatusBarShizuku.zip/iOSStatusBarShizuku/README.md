# iOS Status Bar – Shizuku

Overlay status bar bergaya iPhone untuk Android 13 (Redmi Note 10S, MIUI/HyperOS), tanpa root, memakai Shizuku.

## Keterbatasan (baca dulu)

- **Overlay hanya meniru status bar.** Aplikasi ini tidak mengubah System UI secara langsung.
- **Menyembunyikan status bar asli** memakai setting `policy_control` dengan nilai `immersive.status=*`. Ini setting internal AOSP, bukan API publik. Perilakunya di MIUI/HyperOS belum saya uji, jadi wajib dicoba di HP Anda. Nilai aslinya selalu disimpan dan bisa dikembalikan.
- **Level Wi-Fi** dihitung dari RSSI yang diberikan Android. Jika RSSI tidak terbaca, ikon tampil penuh sebagai "tersambung" dan tidak mengklaim level tertentu.
- **Ikon sinyal seluler** butuh izin Telepon (`READ_PHONE_STATE`). Tanpa izin, ikon itu disembunyikan.
- **Setelah reboot**, server Shizuku mode Wireless Debugging harus dinyalakan ulang manual. Overlay otomatis jalan lagi jika diaktifkan sebelumnya.
- **Project ini belum dikompilasi** di lingkungan pembuatannya (tidak ada Android SDK). Build pertama mungkin menampilkan error kecil. Kirim pesan error lengkapnya dan akan saya perbaiki.

## Struktur folder

```
iOSStatusBarShizuku/
├── settings.gradle.kts
├── build.gradle.kts                      (konfigurasi plugin root)
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── README.md
└── app/
    ├── build.gradle.kts                  (dependency: Shizuku API, Material, AndroidX)
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml           (izin, provider Shizuku, service, receiver)
        ├── aidl/com/example/iosstatusbar/
        │   └── IUserService.aidl         (kontrak UserService Shizuku)
        ├── java/com/example/iosstatusbar/
        │   ├── MainActivity.kt           (UI utama)
        │   ├── BootReceiver.kt           (jalankan ulang overlay setelah reboot)
        │   ├── settings/AppSettings.kt   (penyimpanan lokal SharedPreferences)
        │   ├── shizuku/ShizukuManager.kt (deteksi, izin, bind UserService)
        │   ├── shizuku/ShellUserService.kt (berjalan di proses shell Shizuku)
        │   ├── system/StatusBarController.kt (sembunyikan/kembalikan status bar asli)
        │   ├── system/OverlayPermission.kt   (izin SYSTEM_ALERT_WINDOW)
        │   ├── status/DeviceStatus.kt        (model data status)
        │   ├── status/DeviceStatusMonitor.kt (waktu, baterai, Wi-Fi, seluler)
        │   ├── service/StatusBarOverlayService.kt (window overlay, foreground service)
        │   └── ui/IosStatusBarView.kt        (gambar status bar gaya iOS)
        └── res/
            ├── layout/activity_main.xml
            ├── values/strings.xml, colors.xml, themes.xml
            ├── drawable/ic_launcher_foreground.xml, ic_notification.xml, preview_backdrop.xml
            └── mipmap-anydpi-v26/ic_launcher.xml
```

Package `com.example.iosstatusbar` bisa diganti. Ganti `namespace` dan `applicationId` di `app/build.gradle.kts`, lalu pindahkan folder Java/AIDL sesuai nama paket baru.

## Versi yang dipakai

| Komponen | Versi |
|---|---|
| Android Gradle Plugin | 8.5.2 |
| Gradle | 8.7 |
| Kotlin | 1.9.24 |
| JDK | 17 (bawaan Android Studio) |
| compileSdk / targetSdk / minSdk | 34 / 34 / 26 |
| Shizuku API (`dev.rikka.shizuku:api` dan `provider`) | 13.1.5 |

Cek versi Shizuku terbaru di https://central.sonatype.com/artifact/dev.rikka.shizuku/api lalu ubah di `app/build.gradle.kts`.

## 1. Build APK di Android Studio

1. Ekstrak zip. Folder yang dibuka adalah `iOSStatusBarShizuku` (yang berisi `settings.gradle.kts`).
2. Buka Android Studio, pilih **File > Open**, lalu pilih folder tersebut.
3. Tunggu **Gradle Sync** selesai. Pertama kali, Gradle mengunduh dependency, jadi butuh internet.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

Catatan: zip tidak menyertakan `gradle-wrapper.jar` (file biner). Android Studio biasanya tetap bisa sync karena membaca `gradle-wrapper.properties`. Jika muncul error soal `gradle-wrapper.jar`, jalankan di terminal (Gradle harus terpasang):

```
gradle wrapper --gradle-version 8.7
```

Setelah itu `./gradlew assembleDebug` juga bisa dipakai.

## 2. Instal APK di HP

- Salin `app-debug.apk` ke HP (kabel USB, Google Drive, atau Telegram ke diri sendiri).
- Buka file itu lewat File Manager, lalu pilih **Instal**. Jika diminta, izinkan **Instal aplikasi tidak dikenal** untuk File Manager/Chrome.
- MIUI bisa menampilkan peringatan keamanan. Pilih **Tetap instal** atau **Lanjutkan**.
- Alternatif: dari Android Studio tekan **Run** dengan HP tersambung (USB debugging aktif).

## 3. Hubungkan Shizuku lewat Wireless Debugging (tanpa root)

**a. Aktifkan Opsi Pengembang**
1. Buka **Pengaturan > Tentang ponsel**, lalu ketuk **Versi MIUI** (atau Versi HyperOS) 7 kali sampai muncul pesan "Anda sekarang developer".
2. Buka **Pengaturan > Pengaturan tambahan > Opsi pengembang**. Nama menu bisa sedikit berbeda antarversi.
3. Aktifkan **Debugging nirkabel** (Wireless debugging). Pastikan Wi-Fi HP menyala.

**b. Pasang dan jalankan Shizuku**
1. Pasang aplikasi **Shizuku** dari Play Store atau dari https://github.com/RikkaApps/Shizuku/releases. Nama paketnya `moe.shizuku.privileged.api`.
2. Buka Shizuku, pilih **Start via Wireless debugging** (Android 11 ke atas).
3. Ikuti langkah pairing: buka **Pair device with pairing code** di Opsi pengembang, lalu masukkan kode pairing ke Shizuku.
4. Setelah berhasil, Shizuku menampilkan status **Running**.
5. Untuk MIUI, set **Penghemat baterai > Tanpa batasan** untuk Shizuku dan iOS Status Bar agar tidak dimatikan sistem.

**c. Hubungkan ke iOS Status Bar**
1. Buka iOS Status Bar, lalu tekan **Connect Shizuku**.
2. Pada dialog izin Shizuku, pilih **Izinkan**.
3. Kartu Status Shizuku akan berubah menjadi **Connected**.

**Setiap kali HP dinyalakan ulang:** ulangi langkah b.2–b.4 (Shizuku mode Wireless Debugging tidak bertahan setelah reboot).

Alternatif dengan PC: aktifkan USB debugging, lalu jalankan
```
adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh
```
Perintah ini membutuhkan folder Shizuku di penyimpanan, yang dibuat setelah Shizuku pernah berjalan. Lihat dokumentasi Shizuku bila path berbeda.

## 4. Berikan izin overlay

1. Buka iOS Status Bar, lalu tekan **Beri izin overlay**.
2. Aktifkan **Tampilkan di atas aplikasi lain** untuk iOS Status Bar, lalu kembali ke aplikasi.
3. Tekan **Izin notifikasi dan telepon**, lalu izinkan keduanya. Notifikasi dipakai untuk layanan latar, telepon untuk level sinyal.
4. Pengaturan tambahan MIUI/HyperOS (menu bisa berbeda):
   - **Pengaturan > Aplikasi > Kelola aplikasi > iOS Status Bar**
   - **Autostart**: aktifkan
   - **Penghemat baterai**: Tanpa batasan
   - **Izin lainnya > Tampilkan jendela pop-up saat berjalan di latar belakang**: aktifkan, jika tersedia

Kartu **Izin overlay** akan menampilkan **Ya** setelah izin berhasil.

## 5. Cara pakai

| Tombol | Fungsi |
|---|---|
| **Enable Status Bar** | Menjalankan overlay. Jika opsi "Sembunyikan status bar asli" aktif dan Shizuku terhubung, status bar asli juga disembunyikan. |
| **Disable Status Bar** | Menghentikan overlay dan mengembalikan status bar asli. |
| **Restore Original Status Bar** | Mengembalikan setting sistem yang diubah aplikasi, tanpa mengubah overlay. |

Tema (ikuti sistem, terang, gelap), ukuran ikon (80–140%), dan transparansi latar disimpan lokal di HP dan langsung diterapkan ke preview.

## 6. Pengaman: status bar hilang setelah uninstall

Jika status bar asli masih disembunyikan saat aplikasi dihapus, setting `policy_control` tetap aktif. Cara mengatasinya:

- **Paling aman:** buka aplikasi, tekan **Restore Original Status Bar**, baru uninstall.
- **Dengan PC (ADB):**
  ```
  adb shell settings delete global policy_control
  ```
- Status bar yang tersembunyi juga bisa dimunculkan sementara dengan menggeser dari bagian atas layar.

## 7. Penjelasan teknis singkat

- **Overlay**: `WindowManager` dengan tipe `TYPE_APPLICATION_OVERLAY`, flag `FLAG_NOT_TOUCHABLE` dan `FLAG_NOT_FOCUSABLE`, tinggi sama dengan `status_bar_height`. Sentuhan tetap sampai ke status bar asli dan aplikasi di bawahnya.
- **Posisi cutout**: lebar aman di tepi kiri dan kanan dihitung dari `DisplayCutout`. Cutout di tengah (kamera berlubang Redmi Note 10S) tidak mengurangi area jam dan ikon.
- **Shizuku**: `UserService` (AIDL) berjalan di proses shell Shizuku, bukan root. Hanya kunci `policy_control` yang diizinkan (whitelist). Perintah dijalankan dengan `ProcessBuilder` dan argumen terpisah, tanpa `sh -c`.
- **Data status**: waktu dari sistem, baterai dari `ACTION_BATTERY_CHANGED`, Wi-Fi dari `ConnectivityManager`, dan sinyal seluler dari `TelephonyCallback`. Tidak ada data yang dikarang.
- **Tanpa perubahan permanen**: nilai `policy_control` asli dicadangkan lebih dulu, lalu dikembalikan saat Disable atau Restore. Aplikasi tidak menyentuh partisi sistem atau boot image, jadi risiko bootloop sangat kecil.

## 8. Pemecahan masalah

| Gejala | Kemungkinan penyebab dan solusi |
|---|---|
| Kartu Shizuku "Not Connected" | Server Shizuku belum berjalan (start ulang via Wireless debugging), atau izin belum diberikan. |
| Overlay tidak muncul | Izin "Tampilkan di atas aplikasi lain" belum aktif, atau MIUI menghentikan aplikasi. Cek Autostart dan Penghemat baterai. |
| Status bar asli masih terlihat | Opsi "Sembunyikan status bar asli" belum aktif, atau ROM tidak mengikuti `policy_control`. Overlay tetap berjalan. |
| Ikon sinyal tidak muncul | Izin Telepon belum diberikan, atau tidak ada SIM aktif. |
| Build gagal | Kirim pesan error dari tab **Build** di Android Studio. |
