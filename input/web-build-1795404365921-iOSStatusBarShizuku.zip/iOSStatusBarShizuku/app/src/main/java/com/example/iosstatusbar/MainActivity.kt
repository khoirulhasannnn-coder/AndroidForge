// File: app/src/main/java/com/example/iosstatusbar/MainActivity.kt
package com.example.iosstatusbar

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.iosstatusbar.databinding.ActivityMainBinding
import com.example.iosstatusbar.service.StatusBarOverlayService
import com.example.iosstatusbar.settings.AppSettings
import com.example.iosstatusbar.shizuku.ShizukuManager
import com.example.iosstatusbar.status.DeviceStatusMonitor
import com.example.iosstatusbar.system.OverlayPermission
import com.example.iosstatusbar.system.StatusBarController
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settings: AppSettings
    private var monitor: DeviceStatusMonitor? = null

    // Saat UI diisi dari kode, listener tidak boleh memicu aksi lagi
    private var updatingUi = false

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener { refreshUi() }
    private val binderDeadListener = Shizuku.OnBinderDeadListener { refreshUi() }
    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == ShizukuManager.PERMISSION_REQUEST_CODE) {
                toast(
                    if (grantResult == PackageManager.PERMISSION_GRANTED) R.string.toast_shizuku_granted
                    else R.string.toast_shizuku_denied
                )
            }
            refreshUi()
        }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        // Setelah izin telepon diberikan, monitor dimulai ulang agar sinyal seluler terbaca
        monitor?.restart()
        refreshUi()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        settings = AppSettings(this)
        setupControls()
    }

    override fun onStart() {
        super.onStart()
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        monitor = DeviceStatusMonitor(this) { status -> binding.preview.status = status }
            .also { it.start() }
    }

    override fun onStop() {
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        monitor?.stop()
        monitor = null
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun setupControls() {
        with(binding) {
            btnConnectShizuku.setOnClickListener { connectShizuku() }
            btnEnableStatusBar.setOnClickListener { enableOverlay() }
            btnDisableStatusBar.setOnClickListener { disableOverlay() }
            btnRestoreOriginal.setOnClickListener { restoreOriginal() }
            btnOverlayPermission.setOnClickListener {
                startActivity(OverlayPermission.settingsIntent(this@MainActivity))
            }
            btnExtraPermission.setOnClickListener {
                permissionLauncher.launch(
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.READ_PHONE_STATE)
                )
            }

            groupTheme.setOnCheckedChangeListener { _, checkedId ->
                if (updatingUi) return@setOnCheckedChangeListener
                settings.themeMode = when (checkedId) {
                    R.id.radioLight -> AppSettings.ThemeMode.LIGHT
                    R.id.radioDark -> AppSettings.ThemeMode.DARK
                    else -> AppSettings.ThemeMode.SYSTEM
                }
                pushStyle()
            }

            sliderIconScale.addOnChangeListener { _, value, fromUser ->
                if (fromUser) {
                    settings.iconScalePercent = value.toInt()
                    pushStyle()
                }
            }

            sliderTransparency.addOnChangeListener { _, value, fromUser ->
                if (fromUser) {
                    settings.transparencyPercent = value.toInt()
                    pushStyle()
                }
            }

            switchHideOriginal.setOnCheckedChangeListener { _, isChecked ->
                if (updatingUi) return@setOnCheckedChangeListener
                settings.hideOriginalStatusBar = isChecked
                // Jika overlay sedang aktif, perubahan langsung diterapkan
                if (settings.overlayEnabled) {
                    if (isChecked) hideOriginal() else restoreOriginal()
                }
            }
        }
    }

    /** Memperbarui seluruh teks status dan mengisi kontrol sesuai pengaturan tersimpan. */
    private fun refreshUi() {
        val st = ShizukuManager.state(this)
        updatingUi = true

        binding.textShizukuState.apply {
            setText(if (st.connected) R.string.shizuku_connected else R.string.shizuku_not_connected)
            setTextColor(
                ContextCompat.getColor(context, if (st.connected) R.color.ios_green else R.color.ios_red)
            )
        }
        binding.textShizukuDetail.text = getString(
            R.string.shizuku_detail,
            yesNo(st.managerInstalled),
            yesNo(st.serverRunning),
            yesNo(st.permissionGranted),
        )
        binding.textOverlayState.text = getString(
            R.string.overlay_state,
            getString(if (StatusBarOverlayService.isRunning) R.string.on else R.string.off),
        )
        binding.textOriginalState.text = getString(
            R.string.original_state,
            getString(if (settings.hasPolicyBackup()) R.string.hidden else R.string.visible),
        )
        binding.textOverlayPermission.text = getString(
            R.string.overlay_permission_state,
            yesNo(OverlayPermission.canDraw(this)),
        )

        syncControls()
        updatingUi = false
    }

    /** Mengisi kontrol pengaturan dari penyimpanan lokal. */
    private fun syncControls() {
        binding.groupTheme.check(
            when (settings.themeMode) {
                AppSettings.ThemeMode.SYSTEM -> R.id.radioSystem
                AppSettings.ThemeMode.LIGHT -> R.id.radioLight
                AppSettings.ThemeMode.DARK -> R.id.radioDark
            }
        )
        binding.sliderIconScale.value = settings.iconScalePercent.toFloat()
        binding.sliderTransparency.value = settings.transparencyPercent.toFloat()
        binding.switchHideOriginal.isChecked = settings.hideOriginalStatusBar
        binding.textIconScale.text = "${settings.iconScalePercent}%"
        binding.textTransparency.text = "${settings.transparencyPercent}%"
        applyPreviewStyle()
    }

    private fun applyPreviewStyle() {
        binding.preview.apply {
            isDark = settings.darkTheme(this@MainActivity)
            iconScale = settings.iconScalePercent / 100f
            backgroundOpacity = 1f - settings.transparencyPercent / 100f
        }
    }

    /** Menerapkan gaya baru ke preview dan, jika overlay aktif, ke overlay yang sedang berjalan. */
    private fun pushStyle() {
        applyPreviewStyle()
        binding.textIconScale.text = "${settings.iconScalePercent}%"
        binding.textTransparency.text = "${settings.transparencyPercent}%"
        if (settings.overlayEnabled) {
            startService(serviceIntent(StatusBarOverlayService.ACTION_REFRESH))
        }
    }

    private fun connectShizuku() {
        val st = ShizukuManager.state(this)
        when {
            !st.managerInstalled -> {
                toast(R.string.toast_install_shizuku)
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
            }
            !st.serverRunning -> toast(R.string.toast_start_shizuku)
            !st.permissionGranted -> ShizukuManager.requestPermission()
            else -> toast(R.string.toast_already_connected)
        }
        refreshUi()
    }

    private fun enableOverlay() {
        if (!OverlayPermission.canDraw(this)) {
            toast(R.string.toast_need_overlay)
            startActivity(OverlayPermission.settingsIntent(this))
            return
        }
        settings.overlayEnabled = true
        ContextCompat.startForegroundService(this, serviceIntent(StatusBarOverlayService.ACTION_START))
        if (settings.hideOriginalStatusBar) hideOriginal()
        refreshUi()
    }

    private fun disableOverlay() {
        settings.overlayEnabled = false
        stopService(serviceIntent(StatusBarOverlayService.ACTION_STOP))
        if (settings.hasPolicyBackup()) restoreOriginal() else refreshUi()
    }

    private fun hideOriginal() {
        StatusBarController.hideOriginal(this) { ok ->
            toast(if (ok) R.string.toast_hidden_ok else R.string.toast_hidden_fail)
            refreshUi()
        }
    }

    private fun restoreOriginal() {
        if (!settings.hasPolicyBackup()) {
            toast(R.string.toast_nothing_to_restore)
            refreshUi()
            return
        }
        StatusBarController.restoreOriginal(this) { ok ->
            toast(if (ok) R.string.toast_restored else R.string.toast_restore_fail)
            refreshUi()
        }
    }

    private fun serviceIntent(action: String): Intent =
        Intent(this, StatusBarOverlayService::class.java).setAction(action)

    private fun yesNo(value: Boolean): String = getString(if (value) R.string.yes else R.string.no)

    private fun toast(resId: Int) = Toast.makeText(this, resId, Toast.LENGTH_LONG).show()
}
