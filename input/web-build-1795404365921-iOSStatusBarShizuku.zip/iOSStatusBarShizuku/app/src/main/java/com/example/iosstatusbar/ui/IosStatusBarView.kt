// File: app/src/main/java/com/example/iosstatusbar/ui/IosStatusBarView.kt
package com.example.iosstatusbar.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import com.example.iosstatusbar.status.DeviceStatus
import kotlin.math.roundToInt

/**
 * Menggambar status bar bergaya iOS: jam di kiri, lalu sinyal, Wi-Fi, dan baterai di kanan.
 * Dipakai di overlay dan di preview. Semua ukuran dihitung dari tinggi view,
 * sehingga proporsional di layar apa pun.
 */
class IosStatusBarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    var status: DeviceStatus = DeviceStatus()
        set(value) {
            field = value
            invalidate()
        }

    /** true = ikon putih (gelap), false = ikon hitam (terang). */
    var isDark: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    /** Skala ikon 0.8 .. 1.4 */
    var iconScale: Float = 1f
        set(value) {
            field = value.coerceIn(0.8f, 1.4f)
            invalidate()
        }

    /** Opasitas latar: 1 = tidak transparan, 0 = transparan penuh. */
    var backgroundOpacity: Float = 1f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }

    /** Area yang harus dihindari di kiri dan kanan (mis. sisi cutout), dalam piksel. */
    var leftInset: Int = 0
        set(value) {
            field = value
            invalidate()
        }

    var rightInset: Int = 0
        set(value) {
            field = value
            invalidate()
        }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val rect = RectF()
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val fg = if (isDark) Color.WHITE else Color.BLACK
        val bg = if (isDark) Color.BLACK else Color.WHITE
        val cy = h / 2f
        val pad = h * 0.55f
        val gap = h * 0.24f * iconScale

        // 1. Latar belakang
        bgPaint.color = bg
        bgPaint.alpha = (backgroundOpacity * 255f).roundToInt()
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        // 2. Jam di kiri
        textPaint.color = fg
        textPaint.textSize = h * 0.46f * iconScale
        val textY = cy - (textPaint.descent() + textPaint.ascent()) / 2f
        canvas.drawText(status.timeText, leftInset + pad, textY, textPaint)

        // 3. Ikon di kanan, digambar dari kanan ke kiri: baterai, Wi-Fi, lalu sinyal
        var x = w - rightInset - pad
        x = drawBattery(canvas, x, cy, h, fg, bg) - gap
        if (status.wifiConnected) {
            x = drawWifi(canvas, x, cy, h, fg, status.wifiLevel) - gap
        }
        status.cellularLevel?.let { level ->
            drawSignal(canvas, x, cy, h, fg, level)
        }
    }

    /** Menggambar baterai; mengembalikan koordinat x sisi kiri ikon. */
    private fun drawBattery(canvas: Canvas, rightX: Float, cy: Float, h: Float, fg: Int, bg: Int): Float {
        val bodyH = h * 0.40f * iconScale
        val bodyW = bodyH * 2.05f
        val tipW = bodyH * 0.10f
        val tipH = bodyH * 0.42f
        val stroke = bodyH * 0.09f
        val radius = bodyH * 0.28f
        val left = rightX - tipW - bodyW
        val top = cy - bodyH / 2f
        val bottom = cy + bodyH / 2f

        // Garis luar badan baterai
        strokePaint.color = fg
        strokePaint.alpha = 110
        strokePaint.strokeWidth = stroke
        rect.set(left + stroke / 2f, top + stroke / 2f, left + bodyW - stroke / 2f, bottom - stroke / 2f)
        canvas.drawRoundRect(rect, radius, radius, strokePaint)

        // Ujung kecil di kanan
        fillPaint.color = fg
        fillPaint.alpha = 110
        rect.set(left + bodyW, cy - tipH / 2f, rightX, cy + tipH / 2f)
        canvas.drawRoundRect(rect, tipW / 2f, tipW / 2f, fillPaint)

        // Isi sesuai persentase. Tidak digambar jika level tidak diketahui (-1).
        val level = status.batteryPercent
        if (level in 1..100) {
            val inset = stroke * 1.4f
            val fillW = (bodyW - inset * 2f) * level / 100f
            fillPaint.color = if (level <= 20 && !status.isCharging) LOW_BATTERY_COLOR else fg
            fillPaint.alpha = 255
            rect.set(left + inset, top + inset, left + inset + fillW, bottom - inset)
            canvas.drawRoundRect(rect, radius * 0.5f, radius * 0.5f, fillPaint)
        }

        // Ikon petir saat sedang diisi daya
        if (status.isCharging) {
            fillPaint.color = bg
            fillPaint.alpha = 255
            drawBolt(canvas, left + bodyW / 2f, cy, bodyH * 0.62f)
        }
        return left
    }

    private fun drawBolt(canvas: Canvas, cx: Float, cy: Float, size: Float) {
        val boltW = size * 0.55f
        val points = arrayOf(
            0.15f to -0.50f,
            -0.35f to 0.10f,
            0.00f to 0.10f,
            -0.15f to 0.50f,
            0.35f to -0.10f,
            0.00f to -0.10f,
        )
        path.reset()
        points.forEachIndexed { i, (px, py) ->
            val x = cx + px * boltW
            val y = cy + py * size
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        canvas.drawPath(path, fillPaint)
    }

    /** Menggambar Wi-Fi dari tiga juring; mengembalikan koordinat x sisi kiri ikon. */
    private fun drawWifi(canvas: Canvas, rightX: Float, cy: Float, h: Float, fg: Int, level: Int): Float {
        val size = h * 0.44f * iconScale
        val iconW = size * 1.30f
        val ox = rightX - iconW / 2f
        val oy = cy + size * 0.42f
        val outerR = floatArrayOf(size * 0.95f, size * 0.62f, size * 0.30f)
        val innerR = floatArrayOf(size * 0.66f, size * 0.33f, 0f)
        val lv = level.coerceIn(0, 3)
        for (i in 0..2) {
            // Juring luar aktif jika level penuh; juring titik (paling dalam) selalu aktif bila level >= 1
            fillPaint.color = fg
            fillPaint.alpha = if (lv >= 3 - i) 255 else 70
            drawWedge(canvas, ox, oy, outerR[i], innerR[i], -135f, 90f)
        }
        return rightX - iconW
    }

    private fun drawWedge(
        canvas: Canvas,
        ox: Float,
        oy: Float,
        rOuter: Float,
        rInner: Float,
        startDeg: Float,
        sweepDeg: Float,
    ) {
        path.reset()
        rect.set(ox - rOuter, oy - rOuter, ox + rOuter, oy + rOuter)
        path.arcTo(rect, startDeg, sweepDeg, true)
        if (rInner > 0f) {
            rect.set(ox - rInner, oy - rInner, ox + rInner, oy + rInner)
            path.arcTo(rect, startDeg + sweepDeg, -sweepDeg, false)
        } else {
            path.lineTo(ox, oy)
        }
        path.close()
        canvas.drawPath(path, fillPaint)
    }

    /** Menggambar sinyal seluler 4 batang; mengembalikan koordinat x sisi kiri ikon. */
    private fun drawSignal(canvas: Canvas, rightX: Float, cy: Float, h: Float, fg: Int, level: Int): Float {
        val maxH = h * 0.44f * iconScale
        val barW = maxH * 0.20f
        val gap = maxH * 0.13f
        val totalW = barW * 4f + gap * 3f
        val left = rightX - totalW
        val bottom = cy + maxH / 2f
        val lv = level.coerceIn(0, 4)
        for (i in 0 until 4) {
            val barH = maxH * (0.36f + 0.21f * i)
            val x = left + i * (barW + gap)
            fillPaint.color = fg
            fillPaint.alpha = if (i < lv) 255 else 70
            rect.set(x, bottom - barH, x + barW, bottom)
            canvas.drawRoundRect(rect, barW * 0.3f, barW * 0.3f, fillPaint)
        }
        return left
    }

    companion object {
        private val LOW_BATTERY_COLOR = Color.rgb(255, 69, 58)
    }
}
