# tidak ada aturan khusus
