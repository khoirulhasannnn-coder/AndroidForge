package com.mtzthemeinstaller.mtz

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Element

data class MtzComponent(val label: String, val entryCount: Int)

/** [entryName] persis seperti nama entri di dalam ZIP (dipakai untuk membaca gambar). */
data class MtzPreview(val label: String, val entryName: String)

data class MtzInfo(
    val title: String?,
    val designer: String?,
    val author: String?,
    val version: String?,
    val uiVersion: String?,
    val description: String?,
    val hasDescriptionXml: Boolean,
    val warnings: List<String>,
    val fileEntryCount: Int,
    val components: List<MtzComponent>,
    val previews: List<MtzPreview>,
)

sealed interface MtzValidation {
    data class Valid(val info: MtzInfo) : MtzValidation
    data class Invalid(val reason: String) : MtzValidation
}

/**
 * Validasi dan baca metadata MTZ. MTZ adalah arsip ZIP; tidak ada ekstraksi ke disk di sini
 * (jadi tidak ada risiko zip-slip), hanya membaca daftar entri dan description.xml.
 */
object MtzParser {
    private const val MAX_ENTRIES = 50_000
    private const val MAX_DESCRIPTION_BYTES = 512 * 1024
    private const val MAX_PREVIEWS = 24
    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp")

    /** Penanda struktur tema MIUI (heuristik berdasarkan pola paket tema yang umum). */
    private val KNOWN_TOPS = setOf(
        "wallpaper", "lockscreen", "icons", "fonts", "preview", "launcher",
        "com.android.systemui", "framework-res", "framework-miui-res",
    )

    fun validate(file: File): MtzValidation {
        if (!file.isFile || file.length() < 22) {
            return MtzValidation.Invalid("File kosong atau terlalu kecil untuk berupa arsip ZIP")
        }
        val magic = ByteArray(4)
        val read = file.inputStream().use { it.read(magic) }
        val isPk = read == 4 && magic[0] == 0x50.toByte() && magic[1] == 0x4B.toByte() &&
            magic[2] == 0x03.toByte() && magic[3] == 0x04.toByte()
        if (!isPk) {
            return MtzValidation.Invalid("Bukan arsip ZIP (header 'PK' tidak ditemukan). MTZ asli adalah ZIP.")
        }
        val zip = try {
            ZipFile(file)
        } catch (e: Exception) {
            return MtzValidation.Invalid("Arsip ZIP rusak: ${e.message}")
        }
        return zip.use { z ->
            val files = ArrayList<ZipEntry>()
            val en = z.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (files.size >= MAX_ENTRIES) return MtzValidation.Invalid("Terlalu banyak entri (> $MAX_ENTRIES)")
                if (!e.isDirectory) files += e
            }
            if (files.isEmpty()) return MtzValidation.Invalid("Arsip ZIP tidak berisi file")

            val named = files.map { it.name to norm(it.name) }
            if (named.any { (_, n) -> n.startsWith("/") || n.split('/').any { seg -> seg == ".." } }) {
                return MtzValidation.Invalid("Arsip berisi path berbahaya (path traversal)")
            }

            val descEntry = files.firstOrNull { norm(it.name).equals("description.xml", ignoreCase = true) }
            val warnings = mutableListOf<String>()
            var meta: Map<String, String> = emptyMap()
            if (descEntry == null) {
                warnings += "description.xml tidak ditemukan; metadata tema tidak tersedia"
            } else {
                val bytes = z.getInputStream(descEntry).use { readLimited(it, MAX_DESCRIPTION_BYTES) }
                meta = parseDescription(bytes)
                if (meta.isEmpty()) warnings += "description.xml ada tetapi tidak dapat dibaca"
            }

            val counts = named.map { (_, n) -> n.substringBefore('/') }.groupingBy { it }.eachCount()
            val recognized = descEntry != null || counts.keys.any { it.lowercase() in KNOWN_TOPS }
            if (!recognized) {
                return MtzValidation.Invalid(
                    "ZIP valid, tetapi tidak berisi struktur tema MIUI yang dikenali " +
                        "(description.xml, wallpaper, icons, lockscreen, fonts, ...)"
                )
            }

            val components = counts.entries
                .filterNot { it.key.equals("description.xml", ignoreCase = true) }
                .sortedBy { it.key.lowercase() }
                .map { MtzComponent(labelFor(it.key), it.value) }

            val images = named.filter { (_, n) -> n.substringAfterLast('.', "").lowercase() in IMAGE_EXT }
            val previews = (
                images.filter { (_, n) -> n.lowercase().startsWith("preview/") }
                    .sortedBy { it.second }
                    .map { (orig, n) -> MtzPreview(previewLabel(n), orig) } +
                    images.filter { (_, n) -> n.lowercase().startsWith("wallpaper/") }
                        .sortedBy { it.second }
                        .map { (orig, n) -> MtzPreview("Wallpaper · " + n.substringAfterLast('/'), orig) }
                ).take(MAX_PREVIEWS)

            MtzValidation.Valid(
                MtzInfo(
                    title = meta["title"],
                    designer = meta["designer"],
                    author = meta["author"],
                    version = meta["version"],
                    uiVersion = meta["uiversion"],
                    description = meta["description"],
                    hasDescriptionXml = descEntry != null,
                    warnings = warnings,
                    fileEntryCount = files.size,
                    components = components,
                    previews = previews,
                )
            )
        }
    }

    /** Mengembalikan peta tagName(lowercase) -> teks untuk elemen daun. Kosong jika XML tidak valid. */
    internal fun parseDescription(raw: ByteArray): Map<String, String> {
        val bytes = if (raw.size >= 3 && raw[0] == 0xEF.toByte() && raw[1] == 0xBB.toByte() && raw[2] == 0xBF.toByte()) {
            raw.copyOfRange(3, raw.size)
        } else raw
        return try {
            val factory = DocumentBuilderFactory.newInstance().apply {
                runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
                isExpandEntityReferences = false
            }
            val doc = factory.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
            val result = linkedMapOf<String, String>()
            val all = doc.getElementsByTagName("*")
            for (i in 0 until all.length) {
                val el = all.item(i) as? Element ?: continue
                if (el.getElementsByTagName("*").length != 0) continue // hanya elemen daun
                val key = el.tagName.lowercase()
                val text = el.textContent?.trim().orEmpty()
                if (text.isNotEmpty() && key !in result) result[key] = text
            }
            result
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun norm(name: String) = name.replace('\\', '/')

    private fun labelFor(top: String): String = when (top.lowercase()) {
        "wallpaper" -> "Wallpaper"
        "lockscreen" -> "Lock screen"
        "icons" -> "Ikon aplikasi"
        "fonts" -> "Font"
        "preview" -> "Gambar preview"
        "launcher" -> "Launcher"
        "com.android.systemui" -> "SystemUI (status bar, panel)"
        else -> top
    }

    private fun previewLabel(path: String): String {
        val base = path.substringAfterLast('/').lowercase()
        return when {
            "lockscreen" in base -> "Lock screen"
            "launcher" in base -> "Layar utama / ikon"
            "cover" in base -> "Sampul"
            "font" in base -> "Font"
            "statusbar" in base || "systemui" in base -> "Status bar"
            else -> base
        }
    }

    private fun readLimited(input: InputStream, max: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > max) break
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }
}
