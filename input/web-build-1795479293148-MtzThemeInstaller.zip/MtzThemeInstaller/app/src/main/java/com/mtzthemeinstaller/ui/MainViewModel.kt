package com.mtzthemeinstaller.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mtzthemeinstaller.mtz.ImportResult
import com.mtzthemeinstaller.mtz.MtzPreviewLoader
import com.mtzthemeinstaller.mtz.MtzValidation
import com.mtzthemeinstaller.mtz.ThemeRepository
import com.mtzthemeinstaller.system.DeviceInspector
import com.mtzthemeinstaller.system.LaunchResult
import com.mtzthemeinstaller.system.ThemeLauncher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ThemeRepository(app)
    private val prefs = app.getSharedPreferences("state", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(
        UiState(
            confirmedThemeId = prefs.getString(KEY_ID, null),
            confirmedAtMs = prefs.getLong(KEY_AT, 0L).takeIf { it > 0 },
        )
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        refreshDevice()
        viewModelScope.launch(Dispatchers.IO) {
            val list = repo.list()
            _state.update { it.copy(themes = list) }
        }
    }

    fun refreshDevice() {
        viewModelScope.launch {
            val report = DeviceInspector.read(getApplication())
            _state.update { it.copy(device = report) }
        }
    }

    fun importUri(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            val result = repo.import(uri)
            val list = withContext(Dispatchers.IO) { repo.list() }
            _state.update { it.copy(themes = list, busy = false) }
            when (result) {
                is ImportResult.Success -> {
                    toast("Berhasil diimpor: ${result.record.displayName} (file dibaca dan divalidasi)")
                    select(result.record.id)
                }
                is ImportResult.Duplicate -> {
                    toast("Tema yang sama (isi identik) sudah ada: ${result.existing.displayName}")
                    select(result.existing.id)
                }
                is ImportResult.Rejected -> toast("Ditolak: ${result.reason}")
            }
        }
    }

    fun select(id: String) {
        _state.update { it.copy(selectedId = id, selectedInfo = null, selectedProblem = null, previews = null) }
        val record = _state.value.themes.firstOrNull { it.id == id } ?: return
        viewModelScope.launch {
            val v = withContext(Dispatchers.IO) { com.mtzthemeinstaller.mtz.MtzParser.validate(repo.fileOf(record)) }
            _state.update {
                if (it.selectedId != id) it
                else when (v) {
                    is MtzValidation.Valid -> it.copy(selectedInfo = v.info)
                    is MtzValidation.Invalid -> it.copy(selectedProblem = v.reason)
                }
            }
        }
    }

    fun loadPreviews() {
        val s = _state.value
        val record = s.themes.firstOrNull { it.id == s.selectedId } ?: return
        val info = s.selectedInfo ?: return
        viewModelScope.launch {
            val items = withContext(Dispatchers.IO) {
                info.previews.take(8).map { p ->
                    val bmp = MtzPreviewLoader.load(repo.fileOf(record), p.entryName, 720)
                    PreviewItem(p.label, bmp?.asImageBitmap())
                }
            }
            _state.update { if (it.selectedId == record.id) it.copy(previews = items) else it }
        }
    }

    fun delete(id: String) {
        viewModelScope.launch {
            repo.delete(id)
            val list = withContext(Dispatchers.IO) { repo.list() }
            _state.update {
                it.copy(
                    themes = list,
                    selectedId = if (it.selectedId == id) null else it.selectedId,
                    selectedInfo = if (it.selectedId == id) null else it.selectedInfo,
                    previews = if (it.selectedId == id) null else it.previews,
                )
            }
            toast("Salinan tema dihapus dari penyimpanan aplikasi (tema di sistem tidak disentuh)")
        }
    }

    fun openWithThemes(context: Context) {
        val s = _state.value
        val record = s.themes.firstOrNull { it.id == s.selectedId } ?: return
        when (ThemeLauncher.tryOpenWithThemes(context, repo.fileOf(record))) {
            LaunchResult.OPENED -> {
                _state.update { it.copy(awaitingConfirmationId = record.id) }
                toast("Themes dibuka. Selesaikan penerapan di sana, lalu konfirmasi hasilnya di sini.")
            }
            LaunchResult.NOT_HANDLED -> toast(
                "Aplikasi Themes di perangkat ini tidak menerima file langsung. " +
                    "Gunakan Ekspor salinan lalu Import di dalam Themes."
            )
            LaunchResult.NOT_INSTALLED -> toast("Aplikasi Themes Xiaomi tidak ditemukan di perangkat ini")
        }
    }

    fun openThemesApp(context: Context, forThemeId: String? = null) {
        when (ThemeLauncher.openThemesApp(context)) {
            LaunchResult.OPENED -> {
                if (forThemeId != null) _state.update { it.copy(awaitingConfirmationId = forThemeId) }
            }
            LaunchResult.NOT_INSTALLED -> toast("Aplikasi Themes Xiaomi tidak ditemukan di perangkat ini")
            LaunchResult.NOT_HANDLED -> toast("Tidak dapat membuka aplikasi Themes")
        }
    }

    fun exportSelected(target: Uri) {
        val s = _state.value
        val record = s.themes.firstOrNull { it.id == s.selectedId } ?: return
        viewModelScope.launch {
            try {
                repo.exportTo(record, target)
                val savedName = withContext(Dispatchers.IO) { repo.queryName(target) }
                val ok = savedName?.lowercase()?.endsWith(".mtz") == true
                _state.update { it.copy(awaitingConfirmationId = record.id) }
                toast(
                    if (ok) "Salinan disimpan sebagai $savedName. Di Themes: Saya > Tema > Import."
                    else "Tersimpan sebagai \"$savedName\" — ekstensi bukan .mtz. Ganti nama menjadi ${record.originalName} sebelum Import."
                )
            } catch (e: Exception) {
                toast("Ekspor gagal: ${e.message}")
            }
        }
    }

    fun confirmApplied(applied: Boolean) {
        val id = _state.value.awaitingConfirmationId ?: return
        if (applied) {
            val now = System.currentTimeMillis()
            prefs.edit().putString(KEY_ID, id).putLong(KEY_AT, now).apply()
            _state.update { it.copy(awaitingConfirmationId = null, confirmedThemeId = id, confirmedAtMs = now) }
        } else {
            _state.update { it.copy(awaitingConfirmationId = null) }
            toast("Belum diterapkan. Status tema aktif tidak diubah.")
        }
    }

    fun clearConfirmedActive() {
        prefs.edit().remove(KEY_ID).remove(KEY_AT).apply()
        _state.update { it.copy(confirmedThemeId = null, confirmedAtMs = null) }
    }

    fun restoreDefault(context: Context) {
        when (ThemeLauncher.openThemesApp(context)) {
            LaunchResult.OPENED -> toast("Di Themes pilih tema bawaan (default) dan tekan Terapkan, lalu hapus konfirmasi di dashboard.")
            else -> toast("Aplikasi Themes tidak dapat dibuka. Pulihkan lewat Pengaturan > Wallpaper dan personalisasi.")
        }
    }

    fun consumeMessage() = _state.update { it.copy(message = null) }
    private fun toast(msg: String) = _state.update { it.copy(message = msg) }

    private companion object {
        const val KEY_ID = "confirmed_id"
        const val KEY_AT = "confirmed_at"
    }
}
