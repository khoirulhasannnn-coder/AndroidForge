package com.mtzthemeinstaller

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.mtzthemeinstaller.ui.AppTheme
import com.mtzthemeinstaller.ui.MainScreen
import com.mtzthemeinstaller.ui.MainViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { MainScreen(viewModel) } }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshDevice() // versi Themes bisa berubah saat pengguna kembali dari Play Store/Themes
    }
}
