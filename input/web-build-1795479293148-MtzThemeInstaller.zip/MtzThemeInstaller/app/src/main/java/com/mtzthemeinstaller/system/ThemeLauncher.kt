package com.mtzthemeinstaller.system

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

enum class LaunchResult { OPENED, NOT_INSTALLED, NOT_HANDLED }

/**
 * Penyerahan ke aplikasi Themes resmi Xiaomi. Aplikasi ini TIDAK menulis ke folder privat Themes
 * dan tidak memodifikasi tema sistem. "OPENED" hanya berarti Activity berhasil dibuka,
 * BUKAN bahwa tema sudah terpasang atau aktif.
 */
object ThemeLauncher {

    fun openThemesApp(context: Context): LaunchResult {
        val intent = context.packageManager.getLaunchIntentForPackage(THEMES_PACKAGE)
            ?: return LaunchResult.NOT_INSTALLED
        return try {
            context.startActivity(intent)
            LaunchResult.OPENED
        } catch (e: ActivityNotFoundException) {
            LaunchResult.NOT_HANDLED
        }
    }

    /**
     * Upaya terbaik: ACTION_VIEW ke aplikasi Themes dengan content URI. Apakah versi Themes
     * di perangkat menerima intent ini TIDAK terverifikasi; jika tidak, hasilnya NOT_HANDLED.
     */
    fun tryOpenWithThemes(context: Context, mtz: File): LaunchResult {
        if (context.packageManager.getLaunchIntentForPackage(THEMES_PACKAGE) == null) {
            return LaunchResult.NOT_INSTALLED
        }
        return try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", mtz)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/octet-stream")
                setPackage(THEMES_PACKAGE)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(intent)
            LaunchResult.OPENED
        } catch (e: ActivityNotFoundException) {
            LaunchResult.NOT_HANDLED
        } catch (e: SecurityException) {
            LaunchResult.NOT_HANDLED
        } catch (e: IllegalArgumentException) {
            LaunchResult.NOT_HANDLED
        }
    }
}
