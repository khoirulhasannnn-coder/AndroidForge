package com.mtzthemeinstaller.ui

import androidx.compose.ui.graphics.ImageBitmap
import com.mtzthemeinstaller.mtz.MtzInfo
import com.mtzthemeinstaller.mtz.ThemeRecord
import com.mtzthemeinstaller.system.DeviceReport

data class PreviewItem(val label: String, val image: ImageBitmap?)

data class UiState(
    val device: DeviceReport? = null,
    val themes: List<ThemeRecord> = emptyList(),
    val selectedId: String? = null,
    val selectedInfo: MtzInfo? = null,
    val selectedProblem: String? = null,
    val previews: List<PreviewItem>? = null, // null = belum diminta
    val busy: Boolean = false,
    val message: String? = null,
    /** Tema yang baru diserahkan ke aplikasi Themes dan menunggu konfirmasi pengguna. */
    val awaitingConfirmationId: String? = null,
    val confirmedThemeId: String? = null,
    val confirmedAtMs: Long? = null,
)
