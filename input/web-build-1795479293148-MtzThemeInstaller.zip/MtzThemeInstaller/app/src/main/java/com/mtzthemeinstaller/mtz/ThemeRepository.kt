package com.mtzthemeinstaller.mtz

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException
import java.security.DigestInputStream
import java.security.MessageDigest
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class ThemeRecord(
    val id: String,
    val originalName: String,
    val sizeBytes: Long,
    val importedAtMs: Long,
    val sha256: String,
    val title: String?,
    val author: String?,
) {
    val displayName: String get() = title ?: originalName
}

sealed interface ImportResult {
    data class Success(val record: ThemeRecord, val info: MtzInfo) : ImportResult
    data class Duplicate(val existing: ThemeRecord) : ImportResult
    data class Rejected(val reason: String) : ImportResult
}

/** Menyimpan salinan MTZ di penyimpanan privat aplikasi (filesDir/themes) beserta index.json. */
class ThemeRepository(private val context: Context) {
    private val dir = File(context.filesDir, "themes").apply { mkdirs() }
    private val indexFile = File(dir, "index.json")
    private val lock = Any()

    fun fileOf(record: ThemeRecord): File = File(dir, "${record.id}.mtz")

    fun list(): List<ThemeRecord> = synchronized(lock) { load().sortedByDescending { it.importedAtMs } }

    suspend fun import(uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        val name = queryName(uri)?.substringAfterLast('/') ?: "theme.mtz"
        if (!name.lowercase().endsWith(".mtz")) {
            return@withContext ImportResult.Rejected("Ekstensi file harus .mtz (nama terpilih: $name)")
        }
        val tmp = File(context.cacheDir, "import-${UUID.randomUUID()}.tmp")
        try {
            val md = MessageDigest.getInstance("SHA-256")
            var total = 0L
            val input = context.contentResolver.openInputStream(uri)
                ?: return@withContext ImportResult.Rejected("Tidak dapat membuka file yang dipilih")
            DigestInputStream(input, md).use { din ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = din.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        total += n
                        if (total > MAX_BYTES) throw IOException("File lebih dari ${MAX_BYTES / (1024 * 1024)} MB")
                    }
                }
            }
            val sha = md.digest().joinToString("") { "%02x".format(it) }

            when (val v = MtzParser.validate(tmp)) {
                is MtzValidation.Invalid -> ImportResult.Rejected(v.reason)
                is MtzValidation.Valid -> synchronized(lock) {
                    val all = load()
                    all.firstOrNull { it.sha256 == sha }?.let { return@synchronized ImportResult.Duplicate(it) }
                    val record = ThemeRecord(
                        id = UUID.randomUUID().toString(),
                        originalName = name,
                        sizeBytes = total,
                        importedAtMs = System.currentTimeMillis(),
                        sha256 = sha,
                        title = v.info.title,
                        author = v.info.author ?: v.info.designer,
                    )
                    val dest = fileOf(record)
                    if (!tmp.renameTo(dest)) {
                        tmp.copyTo(dest, overwrite = true)
                    }
                    all += record
                    save(all)
                    ImportResult.Success(record, v.info)
                }
            }
        } catch (e: Exception) {
            ImportResult.Rejected("Gagal mengimpor: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            tmp.delete()
        }
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) {
        synchronized(lock) {
            val all = load()
            all.firstOrNull { it.id == id }?.let { fileOf(it).delete() }
            save(all.filterNot { it.id == id })
        }
    }

    /** Menyalin MTZ tersimpan ke [target] (URI hasil CreateDocument). Nama asli dipertahankan oleh pemanggil. */
    suspend fun exportTo(record: ThemeRecord, target: Uri) = withContext(Dispatchers.IO) {
        val out = context.contentResolver.openOutputStream(target, "w")
            ?: throw IOException("Tidak dapat menulis ke lokasi tujuan")
        out.use { o -> fileOf(record).inputStream().use { it.copyTo(o) } }
    }

    fun queryName(uri: Uri): String? =
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }

    private fun load(): MutableList<ThemeRecord> {
        if (!indexFile.exists()) return mutableListOf()
        return try {
            val arr = JSONArray(indexFile.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ThemeRecord(
                    id = o.getString("id"),
                    originalName = o.getString("originalName"),
                    sizeBytes = o.getLong("sizeBytes"),
                    importedAtMs = o.getLong("importedAtMs"),
                    sha256 = o.getString("sha256"),
                    title = if (o.isNull("title")) null else o.getString("title"),
                    author = if (o.isNull("author")) null else o.getString("author"),
                )
            }.filter { File(dir, "${it.id}.mtz").isFile }.toMutableList()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    private fun save(list: List<ThemeRecord>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("originalName", it.originalName); put("sizeBytes", it.sizeBytes)
                put("importedAtMs", it.importedAtMs); put("sha256", it.sha256)
                put("title", it.title ?: JSONObject.NULL); put("author", it.author ?: JSONObject.NULL)
            })
        }
        indexFile.writeText(arr.toString())
    }

    private companion object {
        const val MAX_BYTES = 1024L * 1024 * 1024
    }
}
