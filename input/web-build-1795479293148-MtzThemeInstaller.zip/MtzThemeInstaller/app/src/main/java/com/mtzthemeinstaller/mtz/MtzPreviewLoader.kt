package com.mtzthemeinstaller.mtz

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.util.zip.ZipFile
import kotlin.math.max

object MtzPreviewLoader {
    private const val MAX_IMAGE_BYTES = 24L * 1024 * 1024

    /** Membaca satu gambar langsung dari ZIP (tanpa ekstraksi), diperkecil agar hemat memori. */
    fun load(file: File, entryName: String, maxSidePx: Int): Bitmap? {
        return try {
            ZipFile(file).use { zip ->
                val entry = zip.getEntry(entryName) ?: return null
                if (entry.size > MAX_IMAGE_BYTES) return null
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                zip.getInputStream(entry).use { BitmapFactory.decodeStream(it, null, bounds) }
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
                var sample = 1
                while (max(bounds.outWidth, bounds.outHeight) / sample > maxSidePx) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                zip.getInputStream(entry).use { BitmapFactory.decodeStream(it, null, opts) }
            }
        } catch (e: Exception) {
            null
        }
    }
}
