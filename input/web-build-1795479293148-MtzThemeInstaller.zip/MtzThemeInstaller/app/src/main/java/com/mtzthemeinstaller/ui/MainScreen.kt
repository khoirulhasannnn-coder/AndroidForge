package com.mtzthemeinstaller.ui

import android.text.format.DateFormat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mtzthemeinstaller.mtz.MtzInfo
import com.mtzthemeinstaller.mtz.ThemeRecord
import com.mtzthemeinstaller.system.DeviceReport
import java.util.Locale

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme(),
        content = content,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: MainViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var showApplyDialog by remember { mutableStateOf(false) }

    LaunchedEffect(state.message) {
        state.message?.let { snackbar.showSnackbar(it); vm.consumeMessage() }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importUri(uri)
    }
    val selected = state.themes.firstOrNull { it.id == state.selectedId }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri -> if (uri != null) vm.exportSelected(uri) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("MTZ Theme Installer") }) },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { inner ->
        LazyColumn(
            modifier = Modifier.padding(inner).padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { DeviceCard(state.device) }
            item { ActiveThemeCard(state, vm) }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { importLauncher.launch(arrayOf("*/*")) },
                        enabled = !state.busy,
                        modifier = Modifier.weight(1f),
                    ) { Text(if (state.busy) "Memproses…" else "Import MTZ") }
                    OutlinedButton(
                        onClick = { vm.restoreDefault(context) },
                        modifier = Modifier.weight(1f),
                    ) { Text("Restore Default") }
                }
            }

            item { Text("Tema diimpor (${state.themes.size})", style = MaterialTheme.typography.titleMedium) }
            if (state.themes.isEmpty()) {
                item { Text("Belum ada. Tekan Import MTZ dan pilih file .mtz dari penyimpanan.") }
            }
            items(state.themes, key = { it.id }) { t ->
                ThemeRow(t, selected = t.id == state.selectedId) { vm.select(t.id) }
            }

            if (selected != null) {
                item {
                    DetailCard(
                        record = selected,
                        info = state.selectedInfo,
                        problem = state.selectedProblem,
                        previews = state.previews,
                        onPreview = vm::loadPreviews,
                        onApply = { showApplyDialog = true },
                        onExport = { exportLauncher.launch(selected.originalName) },
                        onDelete = { vm.delete(selected.id) },
                    )
                }
            }

            item { PersistenceCard() }
            item { Box(Modifier.height(24.dp)) }
        }
    }

    if (showApplyDialog && selected != null) {
        AlertDialog(
            onDismissRequest = { showApplyDialog = false },
            title = { Text("Terapkan lewat aplikasi Themes") },
            text = {
                Text(
                    "Penerapan dilakukan oleh aplikasi Themes resmi Xiaomi; aplikasi ini tidak mengubah tema sistem.\n\n" +
                        "1. Coba buka langsung (tidak semua versi Themes mendukung).\n" +
                        "2. Jika tidak bisa: Ekspor salinan, lalu di Themes pilih Saya > Tema > Import.\n\n" +
                        "Setelah itu Anda akan diminta mengonfirmasi hasilnya."
                )
            },
            confirmButton = {
                TextButton(onClick = { showApplyDialog = false; vm.openWithThemes(context) }) { Text("Coba buka langsung") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        showApplyDialog = false
                        vm.openThemesApp(context, forThemeId = selected.id)
                    }) { Text("Buka Themes") }
                    TextButton(onClick = { showApplyDialog = false }) { Text("Batal") }
                }
            },
        )
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            content()
        }
    }
}

@Composable
private fun KV(key: String, value: String?) {
    Row(Modifier.fillMaxWidth()) {
        Text(key, Modifier.weight(0.38f), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value?.ifBlank { null } ?: "—", Modifier.weight(0.62f), fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun DeviceCard(d: DeviceReport?) {
    Section("Perangkat, MIUI, dan aplikasi Themes") {
        if (d == null) { Text("Membaca…"); return@Section }
        KV("Perangkat", "${d.brand} ${d.model}")
        KV("Codename", d.device)
        KV("Android", "${d.androidRelease} (SDK ${d.sdkInt})")
        KV("MIUI", d.miuiVersionName?.let { "$it (${d.miuiVersionCode ?: "?"})" })
        KV("HyperOS", d.hyperOsVersion)
        KV("Region", d.miuiRegion)
        KV("Build", d.buildIncremental)
        KV("Themes", if (d.themes.installed)
            "${d.themes.versionName} (${d.themes.versionCode})" + if (d.themes.enabled == false) " — dinonaktifkan" else ""
        else "tidak ditemukan")
        Text(
            when {
                d.looksLikeRedmiNote10S -> "Codename cocok dengan Redmi Note 10S."
                d.isXiaomiFamily -> "Perangkat Xiaomi, tetapi bukan Redmi Note 10S; belum diuji pada model ini."
                else -> "Tidak terdeteksi MIUI/HyperOS. Impor dan preview tetap berfungsi; penerapan tidak akan bekerja."
            },
            style = MaterialTheme.typography.bodySmall,
        )
    }
}

@Composable
private fun ActiveThemeCard(s: UiState, vm: MainViewModel) {
    Section("Status tema aktif") {
        val confirmed = s.themes.firstOrNull { it.id == s.confirmedThemeId }
        if (confirmed != null && s.confirmedAtMs != null) {
            Text("${confirmed.displayName} — dikonfirmasi oleh Anda pada ${fmtTime(s.confirmedAtMs)}")
            Text(
                "Aplikasi ini tidak membaca tema aktif dari sistem, jadi status ini bisa sudah tidak berlaku " +
                    "(mis. MIUI mereset tema). Periksa langsung di Themes.",
                style = MaterialTheme.typography.bodySmall,
            )
            TextButton(onClick = vm::clearConfirmedActive) { Text("Hapus konfirmasi") }
        } else {
            Text("Belum ada tema yang Anda konfirmasi aktif.")
        }
        if (s.awaitingConfirmationId != null) {
            val t = s.themes.firstOrNull { it.id == s.awaitingConfirmationId }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Apakah \"${t?.displayName ?: "tema"}\" benar-benar sudah diterapkan dan tampil di perangkat?")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.confirmApplied(true) }) { Text("Ya, sudah aktif") }
                        OutlinedButton(onClick = { vm.confirmApplied(false) }) { Text("Belum") }
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemeRow(t: ThemeRecord, selected: Boolean, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant
        ),
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(t.displayName, style = MaterialTheme.typography.titleSmall)
            Text(
                listOfNotNull(t.author, formatSize(t.sizeBytes), t.originalName).joinToString(" · "),
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun DetailCard(
    record: ThemeRecord,
    info: MtzInfo?,
    problem: String?,
    previews: List<PreviewItem>?,
    onPreview: () -> Unit,
    onApply: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit,
) {
    Section("Detail tema") {
        KV("Nama", info?.title ?: record.originalName)
        KV("Pembuat", info?.author)
        KV("Desainer", info?.designer)
        KV("Versi", info?.version)
        KV("UI version", info?.uiVersion)
        KV("Ukuran", formatSize(record.sizeBytes))
        KV("SHA-256", record.sha256.take(16) + "…")
        KV("File asli", record.originalName)
        info?.description?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        if (problem != null) Text("Masalah: $problem", color = MaterialTheme.colorScheme.error)
        info?.warnings?.forEach { Text("⚠ $it", style = MaterialTheme.typography.bodySmall) }
        if (info != null) {
            Text("Isi paket (${info.fileEntryCount} file):", style = MaterialTheme.typography.labelLarge)
            info.components.forEach { Text("• ${it.label}: ${it.entryCount} entri", style = MaterialTheme.typography.bodySmall) }
        }

        when {
            previews == null -> Text(
                if (info?.previews.isNullOrEmpty()) "Paket ini tidak berisi gambar preview/wallpaper yang bisa dibaca."
                else "${info?.previews?.size} gambar tersedia. Tekan Preview untuk memuat.",
                style = MaterialTheme.typography.bodySmall,
            )
            previews.isEmpty() -> Text("Tidak ada gambar yang berhasil dibaca.")
            else -> LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(previews) { p ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (p.image != null) {
                            Image(p.image, p.label, Modifier.height(220.dp), contentScale = ContentScale.Fit)
                        } else {
                            Box(Modifier.size(120.dp, 220.dp)) { Text("gagal dibaca") }
                        }
                        Text(p.label, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onPreview, enabled = info != null, modifier = Modifier.weight(1f)) { Text("Preview") }
            Button(onClick = onApply, enabled = info != null, modifier = Modifier.weight(1f)) { Text("Apply") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onExport, modifier = Modifier.weight(1f)) { Text("Ekspor salinan") }
            OutlinedButton(onClick = onDelete, modifier = Modifier.weight(1f)) { Text("Hapus") }
        }
    }
}

@Composable
private fun PersistenceCard() {
    Section("Mengapa tema bisa kembali ke default?") {
        Text(
            "Laporan pengguna menyebut MIUI/HyperOS mereset tema .mtz pihak ketiga dalam sekitar 30–60 detik, " +
                "atau lewat hitung mundur (mis. 5 menit/5 jam). Ini umumnya dikaitkan dengan pemeriksaan " +
                "lisensi di aplikasi Themes untuk tema yang bukan dari Theme Store resmi. Xiaomi tidak " +
                "mendokumentasikannya, dan penyebab pastinya belum saya verifikasi di perangkat Anda.",
            style = MaterialTheme.typography.bodySmall,
        )
        Text(
            "Aplikasi ini tidak memakai Accessibility, root, layanan latar, atau cara apa pun untuk " +
                "menghalangi pemeriksaan itu, sehingga tidak ada klaim \"permanen\". Jika tema kembali ke " +
                "default, terapkan ulang lewat Themes.",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}

private fun formatSize(b: Long): String = when {
    b >= 1L shl 30 -> String.format(Locale.US, "%.2f GB", b / (1L shl 30).toDouble())
    b >= 1L shl 20 -> String.format(Locale.US, "%.1f MB", b / (1L shl 20).toDouble())
    b >= 1024 -> String.format(Locale.US, "%.0f KB", b / 1024.0)
    else -> "$b B"
}

private fun fmtTime(ms: Long): String = DateFormat.format("dd MMM yyyy HH:mm", ms).toString()
