package com.mtzthemeinstaller.system

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

const val THEMES_PACKAGE = "com.android.thememanager"

data class ThemesAppInfo(
    val installed: Boolean,
    val versionName: String?,
    val versionCode: Long?,
    val enabled: Boolean?,
)

data class DeviceReport(
    val brand: String,
    val model: String,
    val device: String,
    val androidRelease: String,
    val sdkInt: Int,
    val miuiVersionName: String?,
    val miuiVersionCode: String?,
    val miuiRegion: String?,
    val hyperOsVersion: String?,
    val buildIncremental: String?,
    val themes: ThemesAppInfo,
) {
    val isXiaomiFamily: Boolean get() = miuiVersionName != null || miuiVersionCode != null || hyperOsVersion != null
    /** Codename Redmi Note 10S yang saya ketahui adalah "rosemary"; hanya penanda, bukan gerbang. */
    val looksLikeRedmiNote10S: Boolean get() = device.lowercase().startsWith("rosemary")
}

object DeviceInspector {
    private val KEYS = setOf(
        "ro.miui.ui.version.name", "ro.miui.ui.version.code", "ro.miui.region",
        "ro.mi.os.version.name", "ro.build.version.incremental",
    )

    suspend fun read(context: Context): DeviceReport = withContext(Dispatchers.IO) {
        val props = readProps()
        DeviceReport(
            brand = Build.BRAND,
            model = Build.MODEL,
            device = Build.DEVICE,
            androidRelease = Build.VERSION.RELEASE,
            sdkInt = Build.VERSION.SDK_INT,
            miuiVersionName = props["ro.miui.ui.version.name"],
            miuiVersionCode = props["ro.miui.ui.version.code"],
            miuiRegion = props["ro.miui.region"],
            hyperOsVersion = props["ro.mi.os.version.name"],
            buildIncremental = props["ro.build.version.incremental"],
            themes = readThemesApp(context),
        )
    }

    /** `getprop` bisa dijalankan aplikasi biasa (tanpa root). Properti kosong dianggap tidak ada. */
    private fun readProps(): Map<String, String> = try {
        val p = ProcessBuilder("getprop").redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().use { it.readText() }
        p.waitFor()
        val re = Regex("""^\[(.+?)]: \[(.*)]$""")
        text.lineSequence().mapNotNull { re.find(it.trim()) }
            .map { it.groupValues[1] to it.groupValues[2] }
            .filter { it.first in KEYS && it.second.isNotBlank() }
            .toMap()
    } catch (e: Exception) {
        emptyMap()
    }

    @Suppress("DEPRECATION")
    private fun readThemesApp(context: Context): ThemesAppInfo = try {
        val pm = context.packageManager
        val info = pm.getPackageInfo(THEMES_PACKAGE, 0)
        ThemesAppInfo(
            installed = true,
            versionName = info.versionName,
            versionCode = PackageInfoCompat.getLongVersionCode(info),
            enabled = info.applicationInfo?.enabled,
        )
    } catch (e: PackageManager.NameNotFoundException) {
        ThemesAppInfo(false, null, null, null)
    }
}
