package com.mtzthemeinstaller.mtz

import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class MtzParserTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun zipOf(vararg entries: Pair<String, ByteArray>): File {
        val f = tmp.newFile()
        ZipOutputStream(f.outputStream()).use { z ->
            entries.forEach { (n, b) -> z.putNextEntry(ZipEntry(n)); z.write(b); z.closeEntry() }
        }
        return f
    }

    private val desc = """<?xml version="1.0" encoding="utf-8"?>
        <MIUI-Theme><title>Tema Uji</title><author>Budi</author><designer>Budi D</designer>
        <version>1.2</version><uiVersion>13</uiVersion></MIUI-Theme>""".trimIndent().toByteArray()

    @Test fun validMtzReadsMetadataAndComponents() {
        val f = zipOf(
            "description.xml" to desc,
            "preview/preview_cover_0.jpg" to byteArrayOf(1),
            "wallpaper/default_wallpaper.jpg" to byteArrayOf(2),
            "lockscreen" to byteArrayOf(3),
        )
        val v = MtzParser.validate(f) as MtzValidation.Valid
        assertEquals("Tema Uji", v.info.title)
        assertEquals("Budi", v.info.author)
        assertEquals("13", v.info.uiVersion)
        assertEquals(2, v.info.previews.size)
        assertTrue(v.info.components.any { it.label == "Lock screen" })
    }

    @Test fun bomIsStripped() {
        val withBom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + desc
        assertEquals("Tema Uji", MtzParser.parseDescription(withBom)["title"])
    }

    @Test fun nonZipRejected() {
        val f = tmp.newFile().apply { writeText("ini bukan zip, hanya teks biasa yang cukup panjang") }
        assertTrue(MtzParser.validate(f) is MtzValidation.Invalid)
    }

    @Test fun zipWithoutThemeStructureRejected() {
        val f = zipOf("readme.txt" to byteArrayOf(1), "data/x.bin" to byteArrayOf(2))
        assertTrue(MtzParser.validate(f) is MtzValidation.Invalid)
    }

    @Test fun pathTraversalRejected() {
        val f = zipOf("description.xml" to desc, "../evil.txt" to byteArrayOf(1))
        assertTrue(MtzParser.validate(f) is MtzValidation.Invalid)
    }

    @Test fun missingDescriptionIsWarningNotCrash() {
        val f = zipOf("wallpaper/default_wallpaper.jpg" to byteArrayOf(1))
        val v = MtzParser.validate(f) as MtzValidation.Valid
        assertTrue(v.info.warnings.isNotEmpty())
    }
}
