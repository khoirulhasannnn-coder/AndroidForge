# MTZ Theme Installer (Redmi Note 10S / MIUI)

Import, validasi, preview, dan serah-terima tema .mtz ke aplikasi Themes resmi Xiaomi.

## Yang dilakukan dengan data nyata
- Import via Storage Access Framework (tanpa izin penyimpanan). Nama harus berakhiran .mtz,
  isi harus ZIP valid (header PK) dan berstruktur tema MIUI (description.xml / wallpaper / icons / ...).
  Entri path-traversal ditolak. Ekstensi TIDAK pernah diubah. Duplikat dideteksi via SHA-256.
- Metadata dari description.xml (title, author, designer, version, uiVersion, description).
- Preview: gambar preview/ dan wallpaper/ dibaca langsung dari ZIP. Tidak ada gambar -> dilaporkan apa adanya.
- Deteksi MIUI/HyperOS (getprop), codename, Android, versi aplikasi Themes (com.android.thememanager).
- Apply = serah-terima ke Themes (ACTION_VIEW best-effort, buka Themes, atau ekspor salinan lalu Import
  manual di Themes). Status "aktif" hanya dari KONFIRMASI pengguna.

## Yang TIDAK dilakukan
- Tidak membaca tema aktif dari sistem; tidak menulis ke folder privat Themes; tidak ada root.
- Tidak ada "persistence" yang mengakali reset tema MIUI (lihat kartu penjelasan di aplikasi).

## Build
Prasyarat: Android Studio Koala+, JDK 17, SDK 34.
1. Open folder ini di Android Studio, tunggu sync.
2. ./gradlew assembleDebug  -> app/build/outputs/apk/debug/app-debug.apk
   (tanpa wrapper jar: `gradle wrapper --gradle-version 8.7` sekali)
3. ./gradlew testDebugUnitTest  -> uji parser MTZ (6 test)
