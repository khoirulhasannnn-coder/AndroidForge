# Tahap 1: tidak ada aturan khusus
