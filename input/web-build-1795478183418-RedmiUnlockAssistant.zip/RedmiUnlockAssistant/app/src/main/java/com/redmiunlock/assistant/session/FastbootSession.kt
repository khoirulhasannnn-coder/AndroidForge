package com.redmiunlock.assistant.session

import android.content.Context
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import com.redmiunlock.assistant.fastboot.FastbootClient
import com.redmiunlock.assistant.usb.FastbootCandidate
import com.redmiunlock.assistant.usb.FastbootScanner
import com.redmiunlock.assistant.usb.UsbFastbootTransport
import com.redmiunlock.assistant.usb.UsbPermissionRequester
import com.redmiunlock.assistant.fastboot.FastbootTransport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Memegang satu koneksi fastboot aktif. Titik integrasi untuk modul MiUnlockTool di tahap berikutnya. */
class FastbootSession(context: Context) {
    private val appContext = context.applicationContext
    private val usbManager = appContext.getSystemService(Context.USB_SERVICE) as UsbManager
    private val permissionRequester = UsbPermissionRequester(appContext, usbManager)

    @Volatile private var transport: FastbootTransport? = null
    @Volatile var client: FastbootClient? = null
        private set
    @Volatile var connectedDeviceName: String? = null
        private set

    fun scan(): List<FastbootCandidate> = FastbootScanner.scan(usbManager)

    fun hasPermission(device: UsbDevice): Boolean = usbManager.hasPermission(device)

    suspend fun requestPermission(device: UsbDevice): Boolean = permissionRequester.ensure(device)

    suspend fun open(candidate: FastbootCandidate, trace: (String) -> Unit): FastbootClient =
        withContext(Dispatchers.IO) {
            disconnect()
            val t = UsbFastbootTransport.open(usbManager, candidate)
            val c = FastbootClient(t, trace)
            transport = t
            client = c
            connectedDeviceName = candidate.device.deviceName
            c
        }

    fun disconnect() {
        val t = transport
        transport = null
        client = null
        connectedDeviceName = null
        runCatching { t?.close() }
    }
}
