package com.redmiunlock.assistant.fastboot

/** Balasan protokol Fastboot: 4 byte prefix ASCII + pesan. */
sealed class FastbootReply {
    data class Okay(val message: String) : FastbootReply()
    data class Fail(val message: String) : FastbootReply()
    data class Info(val message: String) : FastbootReply()
    data class Text(val message: String) : FastbootReply()
    data class Data(val length: Long) : FastbootReply()

    companion object {
        fun parse(bytes: ByteArray, length: Int): FastbootReply {
            if (length < 4) throw FastbootException("Respons terlalu pendek ($length byte)")
            val prefix = String(bytes, 0, 4, Charsets.US_ASCII)
            val body = String(bytes, 4, length - 4, Charsets.UTF_8).trimEnd('\u0000')
            return when (prefix) {
                "OKAY" -> Okay(body)
                "FAIL" -> Fail(body)
                "INFO" -> Info(body)
                "TEXT" -> Text(body)
                "DATA" -> Data(
                    body.trim().toLongOrNull(16)
                        ?: throw FastbootException("Panjang DATA tidak valid: $body")
                )
                else -> throw FastbootException("Prefix respons tidak dikenal: '$prefix'")
            }
        }
    }
}
