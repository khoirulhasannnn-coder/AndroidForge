package com.redmiunlock.assistant.fastboot

enum class BootloaderState { UNLOCKED, LOCKED, UNKNOWN }

data class FastbootDeviceInfo(
    val product: String? = null,
    val serial: String? = null,
    val unlockedRaw: String? = null,
    val secure: String? = null,
    val bootloaderVersion: String? = null,
    val currentSlot: String? = null,
    val maxDownloadSize: String? = null,
) {
    /** Hanya dari variabel fastboot `unlocked`; UNKNOWN jika perangkat tidak mengeksposnya. */
    val bootloaderState: BootloaderState
        get() = when (unlockedRaw?.trim()?.lowercase()) {
            "yes", "true", "1" -> BootloaderState.UNLOCKED
            "no", "false", "0" -> BootloaderState.LOCKED
            else -> BootloaderState.UNKNOWN
        }
}

object FastbootDeviceReader {
    private val VARS = listOf(
        "product", "serialno", "unlocked", "secure",
        "version-bootloader", "current-slot", "max-download-size",
    )

    /** Membaca variabel satu per satu; [onUpdate] dipanggil tiap variabel agar UI real-time. */
    fun read(client: FastbootClient, onUpdate: (FastbootDeviceInfo) -> Unit): FastbootDeviceInfo {
        var info = FastbootDeviceInfo()
        for (name in VARS) {
            val value = client.getVar(name)?.trim()?.takeIf { it.isNotEmpty() }
            info = when (name) {
                "product" -> info.copy(product = value)
                "serialno" -> info.copy(serial = value)
                "unlocked" -> info.copy(unlockedRaw = value)
                "secure" -> info.copy(secure = value)
                "version-bootloader" -> info.copy(bootloaderVersion = value)
                "current-slot" -> info.copy(currentSlot = value)
                "max-download-size" -> info.copy(maxDownloadSize = value)
                else -> info
            }
            onUpdate(info)
        }
        return info
    }
}
