package com.redmiunlock.assistant.usb

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import com.redmiunlock.assistant.fastboot.FastbootException
import com.redmiunlock.assistant.fastboot.FastbootTransport

/** Transport nyata di atas UsbManager/UsbDeviceConnection (bulkTransfer). Blocking: panggil dari IO thread. */
class UsbFastbootTransport private constructor(
    private val connection: UsbDeviceConnection,
    private val usbInterface: UsbInterface,
    private val bulkIn: UsbEndpoint,
    private val bulkOut: UsbEndpoint,
) : FastbootTransport {

    override fun write(data: ByteArray, timeoutMs: Int) {
        var offset = 0
        while (offset < data.size) {
            val chunk = minOf(data.size - offset, MAX_CHUNK)
            val n = connection.bulkTransfer(bulkOut, data, offset, chunk, timeoutMs)
            if (n <= 0) throw FastbootException("Gagal menulis ke endpoint USB (kode $n)")
            offset += n
        }
    }

    override fun read(buffer: ByteArray, timeoutMs: Int): Int =
        connection.bulkTransfer(bulkIn, buffer, buffer.size, timeoutMs)

    override fun close() {
        runCatching { connection.releaseInterface(usbInterface) }
        runCatching { connection.close() }
    }

    companion object {
        private const val MAX_CHUNK = 16 * 1024

        fun open(usbManager: UsbManager, candidate: FastbootCandidate): UsbFastbootTransport {
            val device = candidate.device
            if (!usbManager.hasPermission(device)) {
                throw FastbootException("Tidak ada izin USB untuk ${device.deviceName}")
            }
            val iface = candidate.usbInterface
            var inEp: UsbEndpoint? = null
            var outEp: UsbEndpoint? = null
            for (i in 0 until iface.endpointCount) {
                val ep = iface.getEndpoint(i)
                if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
            }
            val bulkIn = inEp ?: throw FastbootException("Endpoint bulk IN tidak ditemukan")
            val bulkOut = outEp ?: throw FastbootException("Endpoint bulk OUT tidak ditemukan")

            val conn = usbManager.openDevice(device)
                ?: throw FastbootException("openDevice() mengembalikan null")
            try {
                if (!conn.claimInterface(iface, true)) {
                    throw FastbootException("claimInterface() gagal (interface dipakai proses lain?)")
                }
                return UsbFastbootTransport(conn, iface, bulkIn, bulkOut)
            } catch (t: Throwable) {
                conn.close()
                throw t
            }
        }
    }
}
