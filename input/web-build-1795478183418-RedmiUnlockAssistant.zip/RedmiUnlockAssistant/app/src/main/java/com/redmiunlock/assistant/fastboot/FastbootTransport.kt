package com.redmiunlock.assistant.fastboot

import java.io.Closeable
import java.io.IOException

/** Lapisan transport byte mentah. Implementasi nyata: UsbFastbootTransport. */
interface FastbootTransport : Closeable {
    /** Menulis seluruh [data] ke endpoint bulk OUT, melempar [FastbootException] jika gagal. */
    fun write(data: ByteArray, timeoutMs: Int)

    /** Membaca satu transfer dari bulk IN. Mengembalikan jumlah byte, atau negatif bila timeout/gagal. */
    fun read(buffer: ByteArray, timeoutMs: Int): Int
}

open class FastbootException(message: String, cause: Throwable? = null) : IOException(message, cause)

/** Perangkat membalas FAIL (mis. variabel tidak dikenal). */
class FastbootFailException(val deviceMessage: String) : FastbootException("FAIL: $deviceMessage")
