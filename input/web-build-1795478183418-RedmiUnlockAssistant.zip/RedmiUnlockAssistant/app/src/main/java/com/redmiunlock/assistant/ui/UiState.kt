package com.redmiunlock.assistant.ui

import com.redmiunlock.assistant.fastboot.FastbootDeviceInfo

enum class ConnectionState { DISCONNECTED, REQUESTING_PERMISSION, CONNECTING, CONNECTED, ERROR }

enum class LogLevel { TRACE, INFO, ERROR }

data class LogLine(val id: Long, val timeMs: Long, val level: LogLevel, val text: String)

data class UsbDeviceSummary(
    val deviceName: String,
    val vendorId: Int,
    val productId: Int,
    val manufacturer: String?,
    val productName: String?,
    val usbSerial: String?,
    val hasPermission: Boolean,
) {
    val vidPid: String get() = "%04X:%04X".format(vendorId, productId)
}

data class UiState(
    val connection: ConnectionState = ConnectionState.DISCONNECTED,
    val devices: List<UsbDeviceSummary> = emptyList(),
    val info: FastbootDeviceInfo? = null,
    val log: List<LogLine> = emptyList(),
    val busy: Boolean = false,
)
