package com.redmiunlock.assistant

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.redmiunlock.assistant.ui.AppTheme
import com.redmiunlock.assistant.ui.MainScreen
import com.redmiunlock.assistant.ui.MainViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { MainScreen(viewModel) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        viewModel.refresh() // dipicu USB_DEVICE_ATTACHED saat app sudah terbuka
    }
}
