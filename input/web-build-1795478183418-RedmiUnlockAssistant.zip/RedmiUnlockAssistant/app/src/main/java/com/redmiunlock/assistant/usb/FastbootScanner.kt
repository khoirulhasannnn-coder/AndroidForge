package com.redmiunlock.assistant.usb

import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager

data class FastbootCandidate(val device: UsbDevice, val usbInterface: UsbInterface)

/** Mencari perangkat dengan interface Fastboot (class 0xFF, subclass 0x42, protocol 0x03). */
object FastbootScanner {
    private const val CLASS = 0xFF
    private const val SUBCLASS = 0x42
    private const val PROTOCOL = 0x03

    fun scan(usbManager: UsbManager): List<FastbootCandidate> =
        usbManager.deviceList.values.mapNotNull { device ->
            (0 until device.interfaceCount)
                .map { device.getInterface(it) }
                .firstOrNull {
                    it.interfaceClass == CLASS &&
                        it.interfaceSubclass == SUBCLASS &&
                        it.interfaceProtocol == PROTOCOL
                }
                ?.let { FastbootCandidate(device, it) }
        }
}
