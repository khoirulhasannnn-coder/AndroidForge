package com.redmiunlock.assistant.ui

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.redmiunlock.assistant.fastboot.FastbootDeviceReader
import com.redmiunlock.assistant.fastboot.FastbootException
import com.redmiunlock.assistant.session.FastbootSession
import com.redmiunlock.assistant.usb.FastbootCandidate
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val session = FastbootSession(app)
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var job: Job? = null
    private val nextLogId = AtomicLong()

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    log(LogLevel.INFO, "USB: perangkat dicolok")
                    refresh()
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    val device = IntentCompat.getParcelableExtra(
                        intent, UsbManager.EXTRA_DEVICE, UsbDevice::class.java
                    )
                    onDetached(device)
                }
            }
        }
    }

    init {
        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(app, usbReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        refresh()
    }

    /** Pindai ulang perangkat fastboot (ringan, aman di main thread). */
    fun refresh() {
        val list = session.scan().map(::summarize)
        _state.update { it.copy(devices = list) }
    }

    /** Hubungkan (atau hubungkan ulang): izin USB -> buka interface -> baca info. */
    fun connect() = launchOp {
        session.disconnect()
        _state.update { it.copy(info = null) }
        val target = session.scan().firstOrNull() ?: throw FastbootException(
            "Tidak ada perangkat Fastboot. Pastikan Redmi di mode Fastboot dan kabel OTG terpasang."
        )
        refresh()
        log(LogLevel.INFO, "Target: ${describe(target)}")

        setConnection(ConnectionState.REQUESTING_PERMISSION)
        if (!session.requestPermission(target.device)) throw FastbootException("Izin USB ditolak")

        setConnection(ConnectionState.CONNECTING)
        session.open(target) { log(LogLevel.TRACE, it) }
        refresh() // sekarang izin ada, serial USB bisa ikut tampil
        setConnection(ConnectionState.CONNECTED)
        log(LogLevel.INFO, "Interface Fastboot berhasil di-claim")

        readInfoInternal()
    }

    fun readInfo() = launchOp { readInfoInternal() }

    fun dumpAll() = launchOp {
        val client = session.client ?: throw FastbootException("Belum terhubung")
        val lines = withContext(Dispatchers.IO) { client.getAllVars() }
        log(LogLevel.INFO, "getvar:all selesai (${lines.size} baris)")
    }

    fun disconnect() {
        job?.cancel()
        job = null
        session.disconnect()
        _state.update { it.copy(connection = ConnectionState.DISCONNECTED, busy = false, info = null) }
        log(LogLevel.INFO, "Koneksi diputus")
        refresh()
    }

    private suspend fun readInfoInternal() {
        val client = session.client ?: throw FastbootException("Belum terhubung")
        withContext(Dispatchers.IO) {
            FastbootDeviceReader.read(client) { info -> _state.update { it.copy(info = info) } }
        }
        log(LogLevel.INFO, "Pembacaan info selesai")
    }

    private fun launchOp(block: suspend () -> Unit) {
        if (job?.isActive == true) return
        job = viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                session.disconnect()
                log(LogLevel.ERROR, e.message ?: e.javaClass.simpleName)
                setConnection(ConnectionState.ERROR)
            } finally {
                _state.update { it.copy(busy = false) }
            }
        }
    }

    private fun onDetached(device: UsbDevice?) {
        log(LogLevel.INFO, "USB: perangkat dicabut")
        if (device != null && device.deviceName == session.connectedDeviceName) {
            job?.cancel()
            job = null
            session.disconnect()
            _state.update { it.copy(connection = ConnectionState.DISCONNECTED, busy = false, info = null) }
        }
        refresh()
    }

    private fun setConnection(c: ConnectionState) = _state.update { it.copy(connection = c) }

    private fun log(level: LogLevel, text: String) {
        val line = LogLine(nextLogId.incrementAndGet(), System.currentTimeMillis(), level, text)
        _state.update { it.copy(log = (it.log + line).takeLast(MAX_LOG)) }
    }

    private fun describe(c: FastbootCandidate): String =
        "%04X:%04X (%s)".format(c.device.vendorId, c.device.productId, c.device.deviceName)

    private fun summarize(c: FastbootCandidate): UsbDeviceSummary {
        val d = c.device
        val perm = session.hasPermission(d)
        return UsbDeviceSummary(
            deviceName = d.deviceName,
            vendorId = d.vendorId,
            productId = d.productId,
            manufacturer = runCatching { d.manufacturerName }.getOrNull(),
            productName = runCatching { d.productName }.getOrNull(),
            usbSerial = if (perm) runCatching { d.serialNumber }.getOrNull() else null,
            hasPermission = perm,
        )
    }

    override fun onCleared() {
        runCatching { getApplication<Application>().unregisterReceiver(usbReceiver) }
        session.disconnect()
        super.onCleared()
    }

    private companion object {
        const val MAX_LOG = 500
    }
}
