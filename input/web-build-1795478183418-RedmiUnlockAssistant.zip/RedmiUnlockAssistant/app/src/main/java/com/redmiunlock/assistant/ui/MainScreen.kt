package com.redmiunlock.assistant.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.redmiunlock.assistant.fastboot.BootloaderState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme(),
        content = content,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: MainViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val connected = state.connection == ConnectionState.CONNECTED

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Redmi Unlock Assistant") },
                actions = { TextButton(onClick = vm::refresh) { Text("Scan") } },
            )
        }
    ) { inner ->
        Column(
            modifier = Modifier
                .padding(inner)
                .padding(horizontal = 12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SectionCard("Status koneksi") {
                Text(
                    when (state.connection) {
                        ConnectionState.DISCONNECTED -> "Terputus"
                        ConnectionState.REQUESTING_PERMISSION -> "Menunggu izin USB…"
                        ConnectionState.CONNECTING -> "Membuka interface Fastboot…"
                        ConnectionState.CONNECTED -> "Terhubung (Fastboot)"
                        ConnectionState.ERROR -> "Error – lihat log"
                    },
                    style = MaterialTheme.typography.titleMedium,
                )
                Text("Tahap 1: hanya baca (getvar). Tidak ada perintah unlock.",
                    style = MaterialTheme.typography.bodySmall)
            }

            SectionCard("Perangkat USB Fastboot") {
                if (state.devices.isEmpty()) {
                    Text("Belum ada. Colok Redmi (mode Fastboot) via OTG lalu tekan Scan.")
                }
                state.devices.forEach { d ->
                    KeyValue("VID:PID", d.vidPid)
                    KeyValue("Nama USB", listOfNotNull(d.manufacturer, d.productName).joinToString(" "))
                    KeyValue("Serial USB", d.usbSerial ?: if (d.hasPermission) null else "(butuh izin)")
                    KeyValue("Izin USB", if (d.hasPermission) "diberikan" else "belum")
                }
            }

            SectionCard("Informasi perangkat (Fastboot)") {
                val info = state.info
                KeyValue("Product", info?.product)
                KeyValue("Serial", info?.serial)
                KeyValue("Bootloader", when (info?.bootloaderState) {
                    BootloaderState.UNLOCKED -> "TERBUKA (unlocked: ${info.unlockedRaw})"
                    BootloaderState.LOCKED -> "TERKUNCI (unlocked: ${info.unlockedRaw})"
                    BootloaderState.UNKNOWN -> "Tidak diketahui (unlocked: ${info.unlockedRaw ?: "tidak ada"})"
                    null -> null
                })
                KeyValue("Secure", info?.secure)
                KeyValue("Ver. bootloader", info?.bootloaderVersion)
                KeyValue("Slot aktif", info?.currentSlot)
                KeyValue("Max download", info?.maxDownloadSize)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = vm::connect,
                    enabled = !state.busy && state.devices.isNotEmpty(),
                    modifier = Modifier.weight(1f),
                ) { Text(if (connected) "Reconnect" else "Hubungkan") }
                OutlinedButton(
                    onClick = vm::disconnect,
                    enabled = state.connection != ConnectionState.DISCONNECTED,
                    modifier = Modifier.weight(1f),
                ) { Text("Disconnect") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = vm::readInfo,
                    enabled = connected && !state.busy,
                    modifier = Modifier.weight(1f),
                ) { Text("Baca info") }
                OutlinedButton(
                    onClick = vm::dumpAll,
                    enabled = connected && !state.busy,
                    modifier = Modifier.weight(1f),
                ) { Text("Dump semua var") }
            }

            LogPanel(state.log)
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            content()
        }
    }
}

@Composable
private fun KeyValue(key: String, value: String?) {
    Row(Modifier.fillMaxWidth()) {
        Text(key, Modifier.weight(0.4f), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value?.ifBlank { null } ?: "—", Modifier.weight(0.6f), fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun LogPanel(lines: List<LogLine>) {
    val listState = rememberLazyListState()
    val fmt = remember { SimpleDateFormat("HH:mm:ss.SSS", Locale.US) }
    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.scrollToItem(lines.lastIndex)
    }
    Card(Modifier.fillMaxWidth().height(300.dp)) {
        LazyColumn(state = listState, modifier = Modifier.padding(8.dp)) {
            items(lines, key = { it.id }) { l ->
                val color: Color = when (l.level) {
                    LogLevel.TRACE -> MaterialTheme.colorScheme.onSurfaceVariant
                    LogLevel.INFO -> MaterialTheme.colorScheme.onSurface
                    LogLevel.ERROR -> MaterialTheme.colorScheme.error
                }
                Text(
                    "${fmt.format(Date(l.timeMs))}  ${l.text}",
                    color = color,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                )
            }
        }
    }
}
