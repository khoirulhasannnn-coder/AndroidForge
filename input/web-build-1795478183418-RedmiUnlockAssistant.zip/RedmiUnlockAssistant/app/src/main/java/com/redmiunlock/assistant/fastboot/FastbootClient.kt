package com.redmiunlock.assistant.fastboot

/**
 * Klien Fastboot TAHAP 1: hanya READ-ONLY.
 *
 * Satu-satunya pintu perintah adalah [execute], yang dengan sengaja menolak apa pun selain
 * "getvar:". Perintah unlock/flash/oem TIDAK ada di tahap ini. Tahap berikutnya sebaiknya
 * menambah kelas terpisah (mis. FastbootUnlockClient) agar jalur read-only ini tetap aman.
 */
class FastbootClient(
    private val transport: FastbootTransport,
    private val trace: (String) -> Unit = {},
) {
    class Result(val infoLines: List<String>, val message: String)

    /** Mengembalikan nilai variabel, atau null jika perangkat membalas FAIL (tidak dikenal). */
    fun getVar(name: String): String? {
        require(VAR_NAME.matches(name)) { "Nama variabel tidak valid: $name" }
        return try {
            execute("getvar:$name", DEFAULT_TIMEOUT_MS).message
        } catch (e: FastbootFailException) {
            null
        }
    }

    /** `getvar:all`: perangkat mengirim banyak baris INFO lalu OKAY. */
    fun getAllVars(): List<String> = execute("getvar:all", GETVAR_ALL_TIMEOUT_MS).infoLines

    private fun execute(command: String, totalTimeoutMs: Long): Result {
        check(command.startsWith("getvar:")) { "Tahap 1 hanya mengizinkan getvar" }
        val payload = command.toByteArray(Charsets.US_ASCII)
        if (payload.size > MAX_COMMAND_BYTES) throw FastbootException("Perintah > $MAX_COMMAND_BYTES byte")

        trace("TX  $command")
        transport.write(payload, WRITE_TIMEOUT_MS)

        val deadline = System.nanoTime() + totalTimeoutMs * 1_000_000L
        val buffer = ByteArray(READ_BUFFER_BYTES)
        val infos = mutableListOf<String>()

        while (true) {
            val remainingMs = (deadline - System.nanoTime()) / 1_000_000L
            if (remainingMs <= 0) throw FastbootException("Timeout menunggu respons '$command'")
            val n = transport.read(buffer, remainingMs.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
            if (n < 0) throw FastbootException("Tidak ada respons / transfer USB gagal untuk '$command'")

            when (val reply = FastbootReply.parse(buffer, n)) {
                is FastbootReply.Okay -> {
                    trace("RX  OKAY ${reply.message}")
                    return Result(infos, reply.message)
                }
                is FastbootReply.Fail -> {
                    trace("RX  FAIL ${reply.message}")
                    throw FastbootFailException(reply.message)
                }
                is FastbootReply.Info -> {
                    trace("RX  INFO ${reply.message}")
                    infos += reply.message
                }
                is FastbootReply.Text -> {
                    trace("RX  TEXT ${reply.message}")
                    infos += reply.message
                }
                is FastbootReply.Data ->
                    throw FastbootException("Perangkat meminta DATA, tidak didukung di tahap 1")
            }
        }
    }

    private companion object {
        val VAR_NAME = Regex("[A-Za-z0-9:_.\\-]{1,48}")
        const val MAX_COMMAND_BYTES = 64
        const val READ_BUFFER_BYTES = 4096
        const val WRITE_TIMEOUT_MS = 2000
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val GETVAR_ALL_TIMEOUT_MS = 30000L
    }
}
