package com.redmiunlock.assistant.fastboot

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeTransport(replies: List<String>) : FastbootTransport {
    private val queue = ArrayDeque(replies.map { it.toByteArray(Charsets.US_ASCII) })
    val written = mutableListOf<String>()
    override fun write(data: ByteArray, timeoutMs: Int) { written += String(data, Charsets.US_ASCII) }
    override fun read(buffer: ByteArray, timeoutMs: Int): Int {
        val r = queue.removeFirstOrNull() ?: return -1
        r.copyInto(buffer)
        return r.size
    }
    override fun close() {}
}

class FastbootClientTest {
    @Test fun getVarReturnsOkayPayload() {
        val t = FakeTransport(listOf("OKAYspes"))
        assertEquals("spes", FastbootClient(t).getVar("product"))
        assertEquals(listOf("getvar:product"), t.written)
    }

    @Test fun getVarFailReturnsNull() {
        assertNull(FastbootClient(FakeTransport(listOf("FAILunknown variable"))).getVar("nope"))
    }

    @Test fun getAllVarsCollectsInfoLines() {
        val t = FakeTransport(listOf("INFOproduct: spes", "INFOunlocked: no", "OKAY"))
        assertEquals(listOf("product: spes", "unlocked: no"), FastbootClient(t).getAllVars())
    }

    @Test fun invalidVarNameRejectedBeforeSending() {
        val t = FakeTransport(emptyList())
        try { FastbootClient(t).getVar("product; oem unlock"); throw AssertionError("harus gagal") }
        catch (_: IllegalArgumentException) {}
        assertTrue(t.written.isEmpty())
    }

    @Test fun bootloaderStateMapping() {
        assertEquals(BootloaderState.UNLOCKED, FastbootDeviceInfo(unlockedRaw = "yes").bootloaderState)
        assertEquals(BootloaderState.LOCKED, FastbootDeviceInfo(unlockedRaw = "no").bootloaderState)
        assertEquals(BootloaderState.UNKNOWN, FastbootDeviceInfo(unlockedRaw = null).bootloaderState)
    }
}
