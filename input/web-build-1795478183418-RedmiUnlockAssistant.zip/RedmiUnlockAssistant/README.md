# Redmi Unlock Assistant — Tahap 1 (Fastboot USB read-only)

Fungsi: deteksi perangkat Fastboot via USB OTG, minta izin USB, baca `product`, `serialno`,
`unlocked`, `secure`, `version-bootloader`, `current-slot`, `max-download-size`, dump `getvar:all`.
TIDAK ada perintah unlock/flash/oem (dikunci di FastbootClient.execute).

## Topologi
HP host (menjalankan app ini) --USB-C/OTG--> kabel USB --> Redmi (mode Fastboot).
Redmi tidak bisa menjalankan app ini sendiri saat berada di Fastboot.
Masuk Fastboot di Redmi: matikan, tahan Volume Bawah + Power.

## Build
Prasyarat: Android Studio (Koala+), JDK 17, Android SDK 34.
1. Android Studio > Open > pilih folder ini > tunggu Gradle sync.
   (Wrapper .jar tidak disertakan; Studio memakai gradle-wrapper.properties. Untuk CLI:
   `gradle wrapper --gradle-version 8.7` sekali, memakai Gradle terpasang.)
2. Debug APK:  ./gradlew assembleDebug
   Hasil: app/build/outputs/apk/debug/app-debug.apk
3. Unit test (protokol, tanpa perangkat): ./gradlew testDebugUnitTest
4. Pasang ke HP host: adb install -r app-debug.apk, atau salin APK lalu izinkan "install unknown apps".

## Struktur
fastboot/  protokol murni Kotlin (tanpa API Android, bisa di-unit-test)
usb/       scanner interface, permission, transport UsbManager
session/   satu koneksi aktif (titik integrasi tahap berikutnya)
ui/        ViewModel (coroutine, Dispatchers.IO) + layar Compose
