package com.example.ioscontrolcenter;

interface IControlService {
    String executeToggle(String name, boolean enabled);
    void destroy() = 16777114;
}
