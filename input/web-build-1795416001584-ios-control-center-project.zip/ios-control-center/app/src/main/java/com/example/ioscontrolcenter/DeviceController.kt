package com.example.ioscontrolcenter

import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.session.MediaSessionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import android.telephony.TelephonyManager

data class MediaUi(
    val title: String = "Belum ada media aktif",
    val artist: String = "Aktifkan akses notifikasi untuk kontrol musik",
    val isPlaying: Boolean = false,
    val available: Boolean = false
)

class DeviceController(private val context: Context) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun wifiEnabled(): Boolean = runCatching {
        val manager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        manager.isWifiEnabled
    }.getOrDefault(false)

    fun bluetoothEnabled(): Boolean = runCatching {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        manager.adapter?.isEnabled == true
    }.getOrDefault(false)

    fun mobileDataEnabled(): Boolean = runCatching {
        val manager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        manager.isDataEnabled
    }.getOrDefault(false)

    fun airplaneEnabled(): Boolean = runCatching {
        Settings.Global.getInt(context.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
    }.getOrDefault(false)

    fun brightnessPermissionGranted(): Boolean = Settings.System.canWrite(context)

    fun brightness(): Float = runCatching {
        Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f
    }.getOrDefault(0.5f).coerceIn(0.02f, 1f)

    fun setBrightness(value: Float): Boolean {
        if (!brightnessPermissionGranted()) return false
        val level = (value.coerceIn(0.02f, 1f) * 255f).toInt().coerceIn(1, 255)
        return runCatching {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, level)
        }.getOrDefault(false)
    }

    fun volume(): Float {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
    }

    fun setVolume(value: Float) {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val index = (value.coerceIn(0f, 1f) * max).toInt()
        runCatching { audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, index, 0) }
    }

    fun notificationListenerGranted(): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        ).orEmpty()
        val expected = ComponentName(context, MediaBridgeService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    fun mediaInfo(): MediaUi {
        if (!notificationListenerGranted()) return MediaUi()
        return try {
            val manager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions = manager.getActiveSessions(ComponentName(context, MediaBridgeService::class.java))
            val controller = sessions.firstOrNull() ?: return MediaUi(
                title = "Tidak ada musik diputar",
                artist = "Putar musik di aplikasi pilihanmu",
                available = true
            )
            val metadata = controller.metadata
            val title = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
                ?: controller.packageName
            val artist = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST)
                ?: metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: "Media aktif"
            val playing = controller.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING
            MediaUi(title, artist, playing, true)
        } catch (_: SecurityException) {
            MediaUi()
        } catch (_: Throwable) {
            MediaUi(title = "Media belum tersedia", artist = "Coba buka aplikasi musik", available = true)
        }
    }

    fun controlMedia(action: String): Boolean {
        if (!notificationListenerGranted()) return false
        return runCatching {
            val manager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val controller = manager.getActiveSessions(ComponentName(context, MediaBridgeService::class.java)).firstOrNull()
                ?: return false
            when (action) {
                "play_pause" -> {
                    val playing = controller.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING
                    if (playing) controller.transportControls.pause() else controller.transportControls.play()
                }
                "next" -> controller.transportControls.skipToNext()
                "previous" -> controller.transportControls.skipToPrevious()
            }
            true
        }.getOrDefault(false)
    }

    fun openWifiSettings() {
        openIntent(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Intent(Settings.Panel.ACTION_WIFI)
            else Intent(Settings.ACTION_WIFI_SETTINGS)
        )
    }

    fun openBluetoothSettings() {
        val isEnabled = bluetoothEnabled()
        val intent = if (!isEnabled) {
            Intent("android.bluetooth.adapter.action.REQUEST_ENABLE")
        } else {
            Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        }
        openIntent(intent)
    }

    fun openMobileSettings() = openIntent(Intent(Settings.ACTION_DATA_USAGE_SETTINGS))
    fun openAirplaneSettings() = openIntent(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
    fun openBrightnessPermission() = openIntent(
        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
            data = android.net.Uri.parse("package:${context.packageName}")
        }
    )
    fun openOverlayPermission() = openIntent(
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
            data = android.net.Uri.parse("package:${context.packageName}")
        }
    )
    fun openNotificationPermission() = openIntent(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    private fun openIntent(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }
}
