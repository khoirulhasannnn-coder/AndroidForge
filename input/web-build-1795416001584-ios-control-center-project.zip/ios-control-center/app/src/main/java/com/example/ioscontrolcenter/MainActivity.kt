package com.example.ioscontrolcenter

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var shizukuService: IControlService? = null
    private var serviceArgs: Shizuku.UserServiceArgs? = null
    private val shizukuReady = mutableStateOf(false)
    private val shizukuMessage = mutableStateOf("Shizuku belum tersambung")

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            shizukuService = IControlService.Stub.asInterface(service)
            shizukuReady.value = shizukuService != null
            shizukuMessage.value = if (shizukuReady.value) "Shizuku siap · UID ${runCatching { Shizuku.getUid() }.getOrDefault(-1)}" else "Gagal menghubungkan layanan Shizuku"
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            shizukuService = null
            shizukuReady.value = false
            shizukuMessage.value = "Koneksi Shizuku terputus"
        }
    }

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_REQUEST_CODE) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                bindShizukuService()
            } else {
                shizukuReady.value = false
                shizukuMessage.value = "Izin Shizuku ditolak"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        val runtimePermissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            runtimePermissions += Manifest.permission.BLUETOOTH_CONNECT
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            runtimePermissions += Manifest.permission.POST_NOTIFICATIONS
        }
        if (runtimePermissions.isNotEmpty()) {
            requestPermissions(runtimePermissions.toTypedArray(), RUNTIME_PERMISSIONS_REQUEST_CODE)
        }

        setContent {
            ControlCenterScreen(
                shizukuReady = shizukuReady.value,
                shizukuMessage = shizukuMessage.value,
                onConnectShizuku = ::connectShizuku,
                onShizukuToggle = ::runShizukuToggle
            )
        }
    }

    private fun connectShizuku() {
        if (!Shizuku.pingBinder()) {
            shizukuMessage.value = "Shizuku belum aktif. Jalankan aplikasi Shizuku terlebih dahulu."
            shizukuReady.value = false
            return
        }
        if (Shizuku.isPreV11()) {
            shizukuMessage.value = "Versi Shizuku terlalu lama. Perbarui Shizuku."
            return
        }
        try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                bindShizukuService()
            } else {
                shizukuMessage.value = "Menunggu izin Shizuku…"
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
            }
        } catch (t: Throwable) {
            shizukuMessage.value = "Shizuku: ${t.message ?: "gagal meminta izin"}"
        }
    }

    private fun bindShizukuService() {
        if (!Shizuku.pingBinder()) {
            shizukuMessage.value = "Shizuku binder tidak tersedia"
            return
        }
        try {
            val args = Shizuku.UserServiceArgs(
                ComponentName(this, ControlUserService::class.java)
            ).daemon(false).tag("ios-control-center-shell-service").version(1)
            serviceArgs = args
            shizukuMessage.value = "Menghubungkan Shizuku…"
            Shizuku.bindUserService(args, serviceConnection)
        } catch (t: Throwable) {
            shizukuReady.value = false
            shizukuMessage.value = "Gagal bind Shizuku: ${t.message ?: t.javaClass.simpleName}"
        }
    }

    private fun runShizukuToggle(name: String, enabled: Boolean) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    shizukuService?.executeToggle(name, enabled) ?: "Layanan Shizuku belum siap. Tekan Sambungkan Shizuku."
                }.getOrElse { "Perintah gagal: ${it.message ?: it.javaClass.simpleName}" }
            }
            shizukuMessage.value = result
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        serviceArgs?.let { args ->
            runCatching { Shizuku.unbindUserService(args, serviceConnection, true) }
        }
        shizukuService = null
        super.onDestroy()
    }

    companion object {
        private const val SHIZUKU_REQUEST_CODE = 4601
        private const val RUNTIME_PERMISSIONS_REQUEST_CODE = 4602
    }
}

@Composable
fun ControlCenterScreen(
    overlayMode: Boolean = false,
    onCloseOverlay: () -> Unit = {},
    shizukuReady: Boolean = false,
    shizukuMessage: String = "Shizuku belum tersambung",
    onConnectShizuku: () -> Unit = {},
    onShizukuToggle: (String, Boolean) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    val controller = remember { DeviceController(context.applicationContext) }
    val prefs = remember { context.getSharedPreferences("control_center", Context.MODE_PRIVATE) }
    var darkMode by remember { mutableStateOf(prefs.getBoolean("dark_mode", true)) }
    var wifi by remember { mutableStateOf(controller.wifiEnabled()) }
    var bluetooth by remember { mutableStateOf(controller.bluetoothEnabled()) }
    var mobile by remember { mutableStateOf(controller.mobileDataEnabled()) }
    var airplane by remember { mutableStateOf(controller.airplaneEnabled()) }
    var brightness by remember { mutableFloatStateOf(controller.brightness()) }
    var volume by remember { mutableFloatStateOf(controller.volume()) }
    var media by remember { mutableStateOf(controller.mediaInfo()) }
    var battery by remember { mutableIntStateOf(readBatteryPercent(context)) }
    var clock by remember { mutableStateOf(currentTime()) }
    var date by remember { mutableStateOf(currentDate()) }
    var feedback by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) {
            wifi = controller.wifiEnabled()
            bluetooth = controller.bluetoothEnabled()
            mobile = controller.mobileDataEnabled()
            airplane = controller.airplaneEnabled()
            brightness = controller.brightness()
            volume = controller.volume()
            media = controller.mediaInfo()
            battery = readBatteryPercent(context)
            clock = currentTime()
            date = currentDate()
            delay(1200)
        }
    }

    val background = if (darkMode) {
        Brush.linearGradient(listOf(Color(0xFF111522), Color(0xFF252D42), Color(0xFF10131C)))
    } else {
        Brush.linearGradient(listOf(Color(0xFFE5ECF8), Color(0xFFD7E3F5), Color(0xFFF5F7FC)))
    }
    val primaryText = if (darkMode) Color(0xFFF7F8FC) else Color(0xFF151B2B)
    val secondaryText = if (darkMode) Color(0xFFB7C1D5) else Color(0xFF56627A)
    val cardColor = if (darkMode) Color(0xFFDBE6FF).copy(alpha = 0.105f) else Color.White.copy(alpha = 0.68f)
    val strokeColor = if (darkMode) Color.White.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.90f)

    MaterialTheme(colorScheme = if (darkMode) darkColorScheme() else lightColorScheme()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(if (overlayMode) Modifier else Modifier.fillMaxSize())
                .background(background),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .fillMaxWidth()
                    .heightIn(max = if (overlayMode) 760.dp else DpInfinity)
                    .then(if (overlayMode) Modifier else Modifier.statusBarsPadding())
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("iOS Control Center", color = primaryText, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("$date  ·  Liquid Glass", color = secondaryText, fontSize = 12.sp)
                    }
                    if (overlayMode) {
                        IconButton(onClick = onCloseOverlay) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup overlay", tint = primaryText)
                        }
                    } else {
                        IconButton(onClick = {
                            darkMode = !darkMode
                            prefs.edit().putBoolean("dark_mode", darkMode).apply()
                        }) {
                            Icon(
                                if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Ganti tema",
                                tint = primaryText
                            )
                        }
                    }
                }

                GlassCard(cardColor, strokeColor, radius = 30) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(clock, color = primaryText, fontSize = 43.sp, fontWeight = FontWeight.Light, letterSpacing = (-1).sp)
                            Text("Control your device", color = secondaryText, fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.BatteryFull, contentDescription = null, tint = if (battery < 20) Color(0xFFFF7777) else Color(0xFF65DDA0), modifier = Modifier.size(21.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("$battery%", color = primaryText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Text("Battery", color = secondaryText, fontSize = 11.sp)
                        }
                    }
                }

                // Connectivity tiles. Without Shizuku the tiles launch Android's official settings panels.
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ControlTile(
                        modifier = Modifier.weight(1f), title = "Wi-Fi", subtitle = if (wifi) "Terhubung / aktif" else "Nonaktif",
                        icon = Icons.Default.Wifi, active = wifi, darkMode = darkMode
                    ) {
                        if (shizukuReady) onShizukuToggle("wifi", !wifi) else controller.openWifiSettings()
                    }
                    ControlTile(
                        modifier = Modifier.weight(1f), title = "Bluetooth", subtitle = if (bluetooth) "Aktif" else "Nonaktif",
                        icon = Icons.Default.Bluetooth, active = bluetooth, darkMode = darkMode
                    ) {
                        if (shizukuReady) onShizukuToggle("bluetooth", !bluetooth) else controller.openBluetoothSettings()
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ControlTile(
                        modifier = Modifier.weight(1f), title = "Data seluler", subtitle = if (mobile) "Aktif" else "Nonaktif",
                        icon = Icons.Default.SignalCellularAlt, active = mobile, darkMode = darkMode
                    ) {
                        if (shizukuReady) onShizukuToggle("mobile", !mobile) else controller.openMobileSettings()
                    }
                    ControlTile(
                        modifier = Modifier.weight(1f), title = "Mode pesawat", subtitle = if (airplane) "Aktif" else "Nonaktif",
                        icon = Icons.Default.Flight, active = airplane, darkMode = darkMode
                    ) {
                        if (shizukuReady) onShizukuToggle("airplane", !airplane) else controller.openAirplaneSettings()
                    }
                }

                GlassCard(cardColor, strokeColor) {
                    Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Brightness6, contentDescription = null, tint = primaryText)
                            Spacer(Modifier.width(10.dp))
                            Text("Kecerahan layar", color = primaryText, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            Text("${(brightness * 100).toInt()}%", color = secondaryText, fontSize = 12.sp)
                        }
                        Slider(
                            value = brightness,
                            onValueChange = {
                                brightness = it
                                if (controller.brightnessPermissionGranted()) {
                                    controller.setBrightness(it)
                                } else {
                                    feedback = "Izinkan Modify system settings untuk mengubah kecerahan."
                                }
                            },
                            valueRange = 0.02f..1f
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = primaryText)
                            Spacer(Modifier.width(10.dp))
                            Text("Volume media", color = primaryText, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            Text("${(volume * 100).toInt()}%", color = secondaryText, fontSize = 12.sp)
                        }
                        Slider(value = volume, onValueChange = {
                            volume = it
                            controller.setVolume(it)
                        }, valueRange = 0f..1f)
                    }
                }

                GlassCard(cardColor, strokeColor) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Now Playing", color = primaryText, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                            Text(if (media.available) "MEDIA SESSION" else "PERLU IZIN", color = secondaryText, fontSize = 9.sp, letterSpacing = 1.sp)
                        }
                        Text(media.title, color = primaryText, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(media.artist, color = secondaryText, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = {
                                if (!controller.controlMedia("previous")) controller.openNotificationPermission()
                            }) { Icon(Icons.Default.SkipPrevious, contentDescription = "Sebelumnya", tint = primaryText, modifier = Modifier.size(28.dp)) }
                            Surface(
                                modifier = Modifier.size(48.dp).clickable {
                                    if (!controller.controlMedia("play_pause")) controller.openNotificationPermission()
                                },
                                shape = CircleShape,
                                color = if (darkMode) Color.White.copy(alpha = .18f) else Color(0xFF27334E).copy(alpha = .10f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        if (media.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Putar / jeda",
                                        tint = primaryText,
                                        modifier = Modifier.size(27.dp)
                                    )
                                }
                            }
                            IconButton(onClick = {
                                if (!controller.controlMedia("next")) controller.openNotificationPermission()
                            }) { Icon(Icons.Default.SkipNext, contentDescription = "Berikutnya", tint = primaryText, modifier = Modifier.size(28.dp)) }
                        }
                        if (!controller.notificationListenerGranted()) {
                            Text(
                                "Aktifkan akses notifikasi agar judul lagu dan tombol media dapat mengontrol sesi musik aktif.",
                                color = secondaryText, fontSize = 11.sp
                            )
                            SmallAction("Aktifkan akses media", darkMode) { controller.openNotificationPermission() }
                        }
                    }
                }

                if (!overlayMode) {
                    GlassCard(cardColor, strokeColor) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Izin & fitur tambahan", color = primaryText, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            SmallAction(
                                if (controller.brightnessPermissionGranted()) "Izin kecerahan aktif" else "Izinkan ubah kecerahan",
                                darkMode
                            ) { controller.openBrightnessPermission() }
                            SmallAction(
                                if (Settings.canDrawOverlays(context)) "Mulai ulang / jalankan overlay" else "Izinkan tampil di atas aplikasi lain",
                                darkMode
                            ) {
                                if (!Settings.canDrawOverlays(context)) {
                                    controller.openOverlayPermission()
                                } else {
                                    runCatching {
                                        ContextCompat.startForegroundService(context, Intent(context, OverlayService::class.java))
                                        feedback = "Overlay dimulai. Geser / gunakan panel mengambang."
                                    }.onFailure { feedback = "Tidak dapat memulai overlay: ${it.message}" }
                                }
                            }
                            SmallAction(
                                if (shizukuReady) "Shizuku tersambung" else "Sambungkan Shizuku",
                                darkMode
                            ) { onConnectShizuku() }
                            SmallAction("Pengaturan akses media", darkMode) { controller.openNotificationPermission() }
                            Text(shizukuMessage, color = secondaryText, fontSize = 11.sp)
                        }
                    }
                } else {
                    SmallAction("Buka setelan overlay / akses media melalui aplikasi utama", darkMode) {
                        context.startActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }

                if (feedback.isNotBlank()) {
                    Text(feedback, color = secondaryText, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 4.dp))
                }
                Text(
                    "Kontrol sistem mengikuti batasan Android dan izin perangkat. Tanpa Shizuku, ubin konektivitas membuka setelan resmi.",
                    color = secondaryText.copy(alpha = .8f), fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
private fun ControlTile(
    modifier: Modifier,
    title: String,
    subtitle: String,
    icon: ImageVector,
    active: Boolean,
    darkMode: Boolean,
    onClick: () -> Unit
) {
    val tileTarget = if (active) Color(0xFF3478F6) else if (darkMode) Color.White.copy(alpha = .105f) else Color.White.copy(alpha = .72f)
    val textTarget = if (active) Color.White else if (darkMode) Color(0xFFF5F7FC) else Color(0xFF202A40)
    val tileColor by animateColorAsState(tileTarget, animationSpec = tween(260), label = "tile background")
    val contentColor by animateColorAsState(textTarget, animationSpec = tween(260), label = "tile content")
    Column(
        modifier = modifier
            .height(112.dp)
            .clip(RoundedCornerShape(25.dp))
            .background(tileColor)
            .border(1.dp, Color.White.copy(alpha = if (active) .35f else .22f), RoundedCornerShape(25.dp))
            .clickable(onClick = onClick)
            .padding(15.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(icon, contentDescription = null, tint = contentColor, modifier = Modifier.size(25.dp))
        Column {
            Text(title, color = contentColor, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, color = contentColor.copy(alpha = .78f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun GlassCard(
    color: Color,
    stroke: Color,
    radius: Int = 26,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(radius.dp))
            .background(Brush.linearGradient(listOf(color, color.copy(alpha = color.alpha * .72f))))
            .border(1.dp, stroke, RoundedCornerShape(radius.dp))
    ) { content() }
}

@Composable
private fun SmallAction(label: String, darkMode: Boolean, onClick: () -> Unit) {
    val bg = if (darkMode) Color.White.copy(alpha = .11f) else Color(0xFF263653).copy(alpha = .08f)
    val fg = if (darkMode) Color(0xFFF4F6FC) else Color(0xFF202A40)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(15.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 13.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = fg, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Icon(Icons.Default.Tune, contentDescription = null, tint = fg.copy(alpha = .75f), modifier = Modifier.size(16.dp))
    }
}

private fun currentTime(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
private fun currentDate(): String = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())

private fun readBatteryPercent(context: Context): Int {
    val intent = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = intent?.getIntExtra("level", -1) ?: -1
    val scale = intent?.getIntExtra("scale", 100) ?: 100
    return if (level >= 0 && scale > 0) (level * 100 / scale).coerceIn(0, 100) else 0
}

private val DpInfinity = 10000.dp
