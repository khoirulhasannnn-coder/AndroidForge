package com.example.ioscontrolcenter

import android.service.notification.NotificationListenerService

/** Enabling this notification listener lets the app see active media sessions. */
class MediaBridgeService : NotificationListenerService()
