package com.example.ioscontrolcenter

import android.util.Log
import androidx.annotation.Keep

/**
 * This class is loaded by Shizuku as UID shell (or root when Sui/root backend is used).
 * It only accepts a small allow-list of system toggles; arbitrary shell input is not exposed.
 */
@Keep
class ControlUserService : IControlService.Stub() {
    override fun destroy() {
        Log.i("IOSCC-Shizuku", "Stopping Shizuku UserService")
        System.exit(0)
    }

    override fun executeToggle(name: String, enabled: Boolean): String {
        val command = when (name) {
            "wifi" -> "svc wifi ${if (enabled) "enable" else "disable"}"
            "bluetooth" -> "svc bluetooth ${if (enabled) "enable" else "disable"}"
            "mobile" -> "svc data ${if (enabled) "enable" else "disable"}"
            "airplane" -> {
                val state = if (enabled) "1" else "0"
                val word = if (enabled) "enable" else "disable"
                "cmd connectivity airplane-mode $word 2>/dev/null || " +
                    "(settings put global airplane_mode_on $state; " +
                    "am broadcast -a android.intent.action.AIRPLANE_MODE --ez state $enabled)"
            }
            else -> return "Ditolak: jenis kontrol tidak dikenal."
        }

        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val output = process.inputStream.bufferedReader().use { it.readText() }.trim()
            val exitCode = process.waitFor()
            Log.i("IOSCC-Shizuku", "$name exit=$exitCode")
            if (exitCode == 0) {
                "Perintah $name dikirim. ${output.ifBlank { "Periksa status perangkat." }}"
            } else {
                "Perangkat menolak perintah ($exitCode). ${output.ifBlank { "Coba lewat Setelan Android." }}"
            }
        } catch (t: Throwable) {
            "Gagal menjalankan perintah: ${t.message ?: t.javaClass.simpleName}"
        }
    }
}
