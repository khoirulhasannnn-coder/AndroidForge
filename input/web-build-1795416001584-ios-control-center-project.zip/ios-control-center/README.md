# iOS Control Center — Android Native

Proyek aplikasi Android native menggunakan **Kotlin + Jetpack Compose** dengan antarmuka bergaya iOS Liquid Glass. Ini adalah aplikasi kontrol tambahan, bukan aplikasi sistem atau pengganti panel Quick Settings bawaan Android.

## Fitur yang dibuat

- UI Liquid Glass dengan kartu transparan, sudut membulat, animasi perubahan warna, dan layout responsif.
- Tema dark mode / light mode yang disimpan.
- Widget jam, tanggal, dan persentase baterai.
- Status Wi-Fi, Bluetooth, data seluler, dan mode pesawat.
- Slider kecerahan layar yang menulis ke `Settings.System`.
- Slider volume media melalui `AudioManager`.
- Kontrol musik sesi aktif: sebelumnya, putar/jeda, berikutnya.
- Panel mengambang melalui `WindowManager` dan `TYPE_APPLICATION_OVERLAY`.
- Integrasi Shizuku memakai `UserService` dan allowlist empat perintah kontrol. Tidak ada kolom untuk menjalankan perintah shell bebas.

## Batasan Android yang perlu diketahui

1. **Wi-Fi:** Untuk aplikasi yang menargetkan Android 10 / API 29 ke atas, Android menolak pemanggilan `WifiManager.setWifiEnabled()` dari aplikasi biasa. Tanpa Shizuku, ubin Wi-Fi membuka panel Wi-Fi resmi. Dengan Shizuku, aplikasi mencoba `svc wifi enable|disable`; sistem/OEM masih dapat menolak perintah.
2. **Bluetooth:** Aplikasi biasa tidak dapat diam-diam menghidupkan atau mematikan Bluetooth pada Android modern. Tanpa Shizuku, ubin meminta izin mengaktifkan Bluetooth atau membuka pengaturan Bluetooth. Jalur Shizuku mencoba `svc bluetooth`.
3. **Data seluler dan mode pesawat:** Keduanya termasuk kontrol yang dilindungi. Tanpa hak sistem, aplikasi membuka halaman Setelan Android. Shizuku mencoba perintah shell, tetapi keberhasilannya bergantung pada versi Android, ROM, operator, dan izin shell.
4. **Kecerahan:** Pengguna harus memberikan izin khusus **Modify system settings**. Saat slider digunakan, mode kecerahan otomatis akan dialihkan ke manual.
5. **Musik:** Pengguna harus mengaktifkan **Notification access** untuk aplikasi ini. Kontrol hanya bekerja jika aplikasi musik menyediakan sesi media aktif.
6. **Overlay:** Pengguna harus memberikan izin **Display over other apps**. Saat overlay aktif, aplikasi menjalankan foreground service dengan notifikasi persisten. Kebijakan baterai beberapa OEM mungkin tetap menghentikan layanan.
7. **Shizuku:** Shizuku harus dipasang dan dijalankan terpisah, lalu izinnya diberikan kepada aplikasi ini. Pada Android 11 ke atas tanpa root, Shizuku bisa dijalankan menggunakan Wireless debugging dari ponsel. Backend ADB Shizuku bukan root; perintah tetap bisa ditolak Android. Biasanya layanan ADB Shizuku perlu dijalankan kembali setelah reboot.

Implementasi Shizuku hanya memakai empat operasi tetap: `wifi`, `bluetooth`, `mobile`, dan `airplane`. UID shell ADB tidak memiliki semua hak root, jadi aplikasi tidak menjanjikan bahwa semua tombol pasti bisa mengubah status sistem pada setiap perangkat.

## Kebutuhan build

- Android Studio dengan dukungan JDK 17.
- Android SDK Platform 36 dan Build Tools 36.0.0.
- Gradle 8.13.
- Android 8.0 (API 26) atau lebih baru untuk menjalankan aplikasi.

## Build APK di Android Studio

1. Ekstrak ZIP proyek.
2. Di Android Studio pilih **Open**, lalu pilih folder `ios-control-center` (folder yang berisi `settings.gradle.kts`).
3. Tunggu Gradle sync. Pasang Android SDK Platform 36 jika diminta.
4. Gunakan Gradle 8.13 jika Android Studio meminta versi Gradle.
5. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

Folder proyek menyertakan file konfigurasi Gradle, tetapi tidak menyertakan instalasi Gradle lokal atau cache dependency.

## Build APK tanpa komputer (GitHub Actions)

Workflow sudah disertakan di `.github/workflows/build-apk.yml`.

1. Buat repository GitHub.
2. Unggah isi folder proyek yang sudah diekstrak ke branch `main`.
3. Buka tab **Actions** pada repository.
4. Pilih **Build iOS Control Center APK**, lalu tekan **Run workflow**. Workflow juga berjalan otomatis saat ada push ke `main`.
5. Setelah proses selesai, buka ringkasan workflow dan unduh artifact `ios-control-center-debug-apk`.
6. Ekstrak artifact tersebut, lalu pasang `app-debug.apk` di Android. Izinkan instalasi dari browser atau file manager saat Android memintanya.

APK dari workflow adalah APK debug untuk pengujian. Untuk distribusi resmi, buat dan gunakan keystore milik sendiri untuk menandatangani APK release.

## Pengaturan pertama kali di ponsel

1. Buka aplikasi **iOS Control Center**.
2. Pilih **Izinkan ubah kecerahan**, lalu izinkan Modify system settings.
3. Pilih **Pengaturan akses media**, lalu aktifkan Notification Access untuk kontrol musik.
4. Pilih izin overlay, aktifkan Display over other apps, lalu kembali ke aplikasi dan tekan lagi untuk memulai panel mengambang.
5. Opsional: jalankan Shizuku, kembali ke aplikasi, tekan **Sambungkan Shizuku**, lalu setujui dialog izinnya.

## Struktur proyek

```text
app/src/main/
  AndroidManifest.xml
  aidl/com/example/ioscontrolcenter/IControlService.aidl
  java/com/example/ioscontrolcenter/
    MainActivity.kt
    DeviceController.kt
    OverlayService.kt
    MediaBridgeService.kt
    ControlUserService.kt
  res/values/
    strings.xml
    styles.xml
```
