package com.indy.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.viewpager2.widget.ViewPager2
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var pager: ViewPager2
    private lateinit var dots: TextView
    private lateinit var apps: List<AppEntry>
    private val shizukuRequestCode = 4107

    data class AppEntry(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(18, 55, 132)
        window.navigationBarColor = Color.rgb(18, 55, 132)
        window.decorView.systemUiVisibility = 0
        apps = loadLaunchableApps()
        buildHome()
    }

    private fun loadLaunchableApps(): List<AppEntry> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull {
                val info = it.activityInfo
                if (info.packageName == packageName) null
                else AppEntry(
                    it.loadLabel(packageManager).toString(),
                    info.packageName,
                    it.loadIcon(packageManager)
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    private fun buildHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(10))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(20, 62, 145), Color.rgb(79, 94, 205), Color.rgb(20, 35, 82))
            )
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val time = TextView(this).apply {
            text = "9:41"
            textSize = 42f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        top.addView(time, LinearLayout.LayoutParams(0, dp(64), 1f))
        val shizuku = TextView(this).apply {
            text = "◉ Shizuku"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = glass(0x44FFFFFF)
            setOnClickListener { showShizukuDialog() }
        }
        top.addView(shizuku)
        root.addView(top)

        val greeting = TextView(this).apply {
            text = "Good Morning  ♡\nINDY LAUNCHER"
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = glass(0x55FFFFFF)
        }
        val greetParams = LinearLayout.LayoutParams(-1, dp(90))
        greetParams.setMargins(0, dp(10), 0, dp(14))
        root.addView(greeting, greetParams)

        pager = ViewPager2(this).apply {
            adapter = AppPagesAdapter()
            offscreenPageLimit = 2
            setPageTransformer { page, position ->
                page.alpha = 1f - (kotlin.math.abs(position) * 0.15f)
                page.scaleY = 1f - (kotlin.math.abs(position) * 0.04f)
            }
        }
        root.addView(pager, LinearLayout.LayoutParams(-1, 0, 1f))

        dots = TextView(this).apply {
            text = "● ○ ○"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(5))
        }
        root.addView(dots)
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                val pages = ((apps.size + 15) / 16).coerceAtLeast(1)
                dots.text = (0 until pages.coerceAtMost(8)).joinToString(" ") {
                    if (it == position) "●" else "○"
                }
            }
        })

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(10))
            background = glass(0x66FFFFFF)
        }
        val dockApps = listOf("Phone", "Messages", "Camera", "Settings")
        dockApps.forEach { label ->
            val tile = TextView(this).apply {
                text = when (label) {
                    "Phone" -> "☎"
                    "Messages" -> "●"
                    "Camera" -> "▣"
                    else -> "⚙"
                }
                textSize = 28f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = glass(0x44FFFFFF)
                setOnClickListener { openByLabel(label) }
            }
            val lp = LinearLayout.LayoutParams(0, dp(54), 1f)
            lp.setMargins(dp(5), 0, dp(5), 0)
            dock.addView(tile, lp)
        }
        val dockParams = LinearLayout.LayoutParams(-1, dp(72))
        dockParams.setMargins(0, dp(8), 0, dp(5))
        root.addView(dock, dockParams)

        setContentView(root)
    }

    private inner class AppPagesAdapter : androidx.recyclerview.widget.RecyclerView.Adapter<PageHolder>() {
        private val pageCount = ((apps.size + 15) / 16).coerceAtLeast(1)

        override fun getItemCount() = pageCount

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageHolder {
            val grid = GridLayout(this@MainActivity).apply {
                columnCount = 4
                alignmentMode = GridLayout.ALIGN_BOUNDS
                useDefaultMargins = false
            }
            return PageHolder(grid)
        }

        override fun onBindViewHolder(holder: PageHolder, position: Int) {
            val grid = holder.grid
            grid.removeAllViews()
            val start = position * 16
            val end = (start + 16).coerceAtMost(apps.size)
            for (index in start until end) {
                val entry = apps[index]
                val cell = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(4), dp(6), dp(4), dp(6))
                }
                val icon = ImageView(this@MainActivity).apply {
                    setImageDrawable(entry.icon)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    background = glass(0x33FFFFFF)
                    setPadding(dp(5), dp(5), dp(5), dp(5))
                }
                cell.addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)))
                val label = TextView(this@MainActivity).apply {
                    text = entry.label
                    textSize = 11f
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
                val lp = LinearLayout.LayoutParams(-1, dp(24))
                lp.topMargin = dp(4)
                cell.addView(label, lp)
                cell.setOnClickListener { launch(entry.packageName) }
                cell.setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(entry.label)
                        .setItems(arrayOf("Open app", "App info")) { _, which ->
                            if (which == 0) launch(entry.packageName)
                            else {
                                val i = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                i.data = android.net.Uri.parse("package:${entry.packageName}")
                                startActivity(i)
                            }
                        }.show()
                    true
                }
                val spec = GridLayout.spec((index - start) / 4, 1f)
                val col = GridLayout.spec((index - start) % 4, 1f)
                grid.addView(cell, GridLayout.LayoutParams(spec, col).apply {
                    width = 0
                    height = dp(96)
                })
            }
        }
    }

    private class PageHolder(val grid: GridLayout) :
        androidx.recyclerview.widget.RecyclerView.ViewHolder(grid)

    private fun launch(packageName: String) {
        packageManager.getLaunchIntentForPackage(packageName)?.let { startActivity(it) }
    }

    private fun openByLabel(label: String) {
        val entry = apps.firstOrNull { it.label.contains(label, true) }
        if (entry != null) launch(entry.packageName)
        else Toast.makeText(this, "$label app not found", Toast.LENGTH_SHORT).show()
    }

    private fun showShizukuDialog() {
        val connected = Shizuku.pingBinder()
        val permitted = connected && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        val message = when {
            !connected -> "Shizuku belum berjalan. Buka Shizuku dan mulai melalui Wireless Debugging."
            permitted -> "Shizuku terhubung dan izin sudah diberikan."
            else -> "Shizuku berjalan. Tekan Request Permission untuk memberikan izin."
        }
        val builder = AlertDialog.Builder(this)
            .setTitle("INDY LAUNCHER · Shizuku")
            .setMessage(message)
            .setPositiveButton(if (connected && !permitted) "Request Permission" else "OK") { _, _ ->
                if (connected && !permitted) {
                    Shizuku.requestPermission(shizukuRequestCode)
                }
            }
            .setNeutralButton("Open Shizuku") { _, _ ->
                val launchIntent = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (launchIntent != null) startActivity(launchIntent)
                else Toast.makeText(this, "Install Shizuku first", Toast.LENGTH_SHORT).show()
            }
        builder.show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == shizukuRequestCode) {
            Toast.makeText(
                this,
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                    "Shizuku permission granted" else "Shizuku permission not granted",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun glass(color: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(24).toFloat()
            setColor(color)
            setStroke(dp(1), 0x66FFFFFF)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
