# INDY LAUNCHER — starter source project

This is a **starter Android launcher project** based on the user's Liquid Glass/iOS-style reference.

Included:
- Native Android HOME launcher intent filters
- Horizontal home pages (no app drawer)
- Launchable app icons and labels
- Simple glass-style dock and home header
- Shizuku binder/permission status dialog
- Android 13-compatible project settings

Important limitations:
- This is a starter implementation, not a finished commercial launcher.
- The reference collage is a visual target; advanced features such as real widgets, drag-and-drop icon placement, folder editing, live Control Center toggles, dynamic blur, custom status bar, and full Shizuku shell actions still need implementation.
- Android 13/MIUI may limit certain system actions. Shizuku does not grant unrestricted access.
- Build has not been run or verified in this environment.

## Build
Open this folder in an Android-compatible IDE or build environment with JDK 17 and Android SDK 35, then run:
`gradle assembleDebug`

Expected APK:
`app/build/outputs/apk/debug/app-debug.apk`

To select it:
Settings → Apps → Default apps → Home app → INDY LAUNCHER
(or use the Android Home chooser).

If using a phone-only cloud builder, upload this entire project ZIP and select Android/Gradle build.
